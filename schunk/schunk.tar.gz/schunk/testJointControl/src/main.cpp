#include <ros/ros.h>
#include <sensor_msgs/JointState.h>

ros::Publisher pub;

void jointStateListen(const sensor_msgs::JointState msg)
{

}


int main(int argc, char** argv)
{
	//Init the ROS node
	ros::init(argc, argv, "testschunkJointController");
	ros::NodeHandle n;
	// subriber
	ros::Subscriber sub = n.subscribe("joint_states", 1000, jointStateListen);

	// publisher
	pub = n.advertise<sensor_msgs::JointState>("/joint_states_command",10);

	sensor_msgs::JointState msg;
	msg.set_position_size(7);
	msg.set_velocity_size(7);
	msg.position[0] = 0;
	msg.position[1] = 0.707;
	msg.position[2] = 0;
	msg.position[3] = 0.707;
	msg.position[4] = 0;
	msg.position[5] = 0.707;
	msg.position[6] = 0;

	for (size_t j = 0; j < 7; ++j)
	{
		msg.velocity[j] = 0.0;
	}
	pub.publish(msg);

	while (n.ok())
	{
		for (size_t j = 0; j < 7; ++j)
		{
			msg.position[j] += 0.1;
		}
		pub.publish(msg);
		usleep(50000);
		ros::spinOnce();
	}
}
