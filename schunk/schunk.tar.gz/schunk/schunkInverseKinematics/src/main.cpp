#include <ros/ros.h>

#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Pose.h>

#include <kinematics_msgs/GetKinematicSolverInfo.h>
#include <kinematics_msgs/GetPositionFK.h>
#include <kinematics_msgs/GetPositionIK.h>

#include <kdl/frames.hpp>

#include <visualization_msgs/Marker.h>

const unsigned int N_DOF = 7;
int j;
// define the service messages
kinematics_msgs::GetKinematicSolverInfo::Request request;
kinematics_msgs::GetKinematicSolverInfo::Response response;
// define the service messages
kinematics_msgs::GetPositionIK::Request  gpik_req;
kinematics_msgs::GetPositionIK::Response gpik_res;

ros::ServiceClient query_client;
ros::ServiceClient ik_client;

sensor_msgs::JointState jointState;


sensor_msgs::JointState robotJoints;
geometry_msgs::Pose robotPose;
ros::Publisher joint_state_pub;
void getIK_Info()
{
	if(query_client.call(request,response))
	{
		for(unsigned int i=0; i< response.kinematic_solver_info.joint_names.size(); i++)
		{
			ROS_DEBUG("Joint: %d %s",i,response.kinematic_solver_info.joint_names[i].c_str());
		}
	}
	else
	{
		ROS_ERROR("Could not call query service");
		ros::shutdown();
		exit(1);
	}
}

void getIK()
{
	gpik_req.timeout = ros::Duration(5.0);
	gpik_req.ik_request.ik_link_name = "arm_7_link";

	gpik_req.ik_request.pose_stamped.header.frame_id = "base_link";

	gpik_req.ik_request.pose_stamped.pose = robotPose;

	gpik_req.ik_request.ik_seed_state.joint_state.position.resize(response.kinematic_solver_info.joint_names.size());
	gpik_req.ik_request.ik_seed_state.joint_state.name = response.kinematic_solver_info.joint_names;

	//	ROS_INFO("Position: %5f   %5f   %5f",gpik_req.ik_request.pose_stamped.pose.position.x,gpik_req.ik_request.pose_stamped.pose.position.y,gpik_req.ik_request.pose_stamped.pose.position.z);
	//	ROS_INFO("Orientation: %5f   %5f   %5f %5f",gpik_req.ik_request.pose_stamped.pose.orientation.x,gpik_req.ik_request.pose_stamped.pose.orientation.y,gpik_req.ik_request.pose_stamped.pose.orientation.z,gpik_req.ik_request.pose_stamped.pose.orientation.w);


	for(unsigned int i=0; i< response.kinematic_solver_info.joint_names.size(); i++)
	{
		gpik_req.ik_request.ik_seed_state.joint_state.position[i] = (response.kinematic_solver_info.limits[i].min_position + response.kinematic_solver_info.limits[i].max_position)/2.0;
	}
	if(ik_client.call(gpik_req, gpik_res))
	{
		if(gpik_res.error_code.val == gpik_res.error_code.SUCCESS)
		{
				robotJoints = gpik_res.solution.joint_state;
//				ROS_INFO("Position : %5d",robotJoints.get_position_size());
				robotJoints.set_velocity_size(N_DOF);
//				ROS_INFO("Velocity : %5d",robotJoints.get_velocity_size());
		}
		else
			ROS_ERROR("Inverse kinematics failed");
	}
	else
		ROS_ERROR("Inverse kinematics service call failed");

}

void EndEfforPoseCB(const geometry_msgs::Pose msg)
{
	robotPose = msg;
	getIK();
	joint_state_pub.publish(robotJoints);
}


int main(int argc, char **argv){
	ros::init (argc, argv, "schunkInverseKinematic");
	ros::NodeHandle n;

	// Subriber for joint states
	ros::Subscriber sub = n.subscribe("/EndEfforPose", 1, EndEfforPoseCB);

	//publisher
	joint_state_pub = n.advertise<sensor_msgs::JointState>("/joint_states_command", 10);


	robotPose.position.x = 0.000001;
	robotPose.position.y = 0.000003;
	robotPose.position.z = 1.667200;
	//
	robotPose.orientation.x = 0;
	robotPose.orientation.y = 1;
	robotPose.orientation.z = 0;
	robotPose.orientation.w = 0;


	ros::service::waitForService("/arm_m_chain_kinematics/get_ik_solver_info");
	ros::service::waitForService("/arm_m_chain_kinematics/get_ik");

	query_client = n.serviceClient<kinematics_msgs::GetKinematicSolverInfo>("/arm_m_chain_kinematics/get_ik_solver_info");
	ik_client = n.serviceClient<kinematics_msgs::GetPositionIK>("/arm_m_chain_kinematics/get_ik");

	getIK_Info();

	ros::spin();
}

