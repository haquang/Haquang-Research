#include <ros/ros.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <actionlib/client/simple_action_client.h>
#include <trajectory_msgs/JointTrajectory.h>
#include <sensor_msgs/JointState.h>

typedef actionlib::SimpleActionClient <control_msgs::FollowJointTrajectoryAction > TrajClient;

// Variable
TrajClient * traj_client_; //Trajectory
control_msgs::FollowJointTrajectoryGoal goal;
int i;

actionlib::SimpleClientGoalState getState()
{
	return traj_client_->getState();
}

void startTrajectory()
{
	// When to start the trajectory: 1s from now
	goal.trajectory.header.stamp = ros::Time::now() + ros::Duration(1.0);
	traj_client_->sendGoal(goal);
}

void jointCommandCallback(const sensor_msgs::JointState msg)
{
	traj_client_ = new TrajClient("/arm_controller/follow_joint_trajectory", true);
	while(!traj_client_->waitForServer(ros::Duration(5.0))){
		ROS_INFO("Waiting for the joint_trajectory_action server");
	}
	// Position
	goal.trajectory.points[0].positions.resize(7);
	goal.trajectory.points[0].positions[0] = msg.position[0];
	goal.trajectory.points[0].positions[1] = msg.position[1];
	goal.trajectory.points[0].positions[2] = msg.position[2];
	goal.trajectory.points[0].positions[3] = msg.position[3];
	goal.trajectory.points[0].positions[4] = msg.position[4];
	goal.trajectory.points[0].positions[5] = msg.position[5];
	goal.trajectory.points[0].positions[6] = msg.position[6];

	//Velocity
	goal.trajectory.points[0].velocities.resize(7);
	goal.trajectory.points[0].velocities[0] = msg.velocity[0];
	goal.trajectory.points[0].velocities[1] = msg.velocity[1];
	goal.trajectory.points[0].velocities[2] = msg.velocity[2];
	goal.trajectory.points[0].velocities[3] = msg.velocity[3];
	goal.trajectory.points[0].velocities[4] = msg.velocity[4];
	goal.trajectory.points[0].velocities[5] = msg.velocity[5];
	goal.trajectory.points[0].velocities[6] = msg.velocity[6];

	goal.trajectory.points[0].time_from_start = ros::Duration(20.0);

	//start Trajectory
	startTrajectory();
	while(!getState().isDone())
	{
		usleep(500);
	}
	delete traj_client_;
}


void initialize()
{
	traj_client_ = new TrajClient("/arm_controller/follow_joint_trajectory", true);
	while(!traj_client_->waitForServer(ros::Duration(5.0))){
		ROS_INFO("Waiting for the joint_trajectory_action server");
	}

	//init goal
	goal.trajectory.joint_names.push_back("arm_1_joint");
	goal.trajectory.joint_names.push_back("arm_2_joint");
	goal.trajectory.joint_names.push_back("arm_3_joint");
	goal.trajectory.joint_names.push_back("arm_4_joint");
	goal.trajectory.joint_names.push_back("arm_5_joint");
	goal.trajectory.joint_names.push_back("arm_6_joint");
	goal.trajectory.joint_names.push_back("arm_7_joint");

	goal.trajectory.points.resize(1);
	goal.trajectory.points[0].positions.resize(7);

	// set to the original position
	goal.trajectory.points[0].positions.resize(7);
	goal.trajectory.points[0].positions[0] = 0.0;
	goal.trajectory.points[0].positions[1] = 0.0;
	goal.trajectory.points[0].positions[2] = 0.0;
	goal.trajectory.points[0].positions[3] = 0.0;
	goal.trajectory.points[0].positions[4] = 0.0;
	goal.trajectory.points[0].positions[5] = 0.0;
	goal.trajectory.points[0].positions[6] = 0;
	goal.trajectory.points[0].velocities.resize(7);


	for (size_t j = 0; j < 7; ++j)
	{
		goal.trajectory.points[0].velocities[j] = 0.0;
	}

	// To be reached 2 seconds after starting along the trajectory
	goal.trajectory.points[0].time_from_start = ros::Duration(20.0);

	//start Trajectory
	startTrajectory();

	while(!getState().isDone())
	{
		usleep(500);
	}
	delete traj_client_;
}
int main(int argc, char** argv)
{
	//Init the ROS node
	ros::init(argc, argv, "schunkJointController");
	ros::NodeHandle n;
	// Initialize
	initialize();

	// subriber
	ros::Subscriber sub = n.subscribe("/joint_states_command", 1, jointCommandCallback);
	// Wait for trajectory completion
	ros::spin();
}
