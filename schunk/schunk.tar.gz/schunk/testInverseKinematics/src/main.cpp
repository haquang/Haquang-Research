#include <ros/ros.h>
#include <geometry_msgs/Pose.h>


geometry_msgs::Pose robotPose;


int main(int argc, char **argv){
	ros::init (argc, argv, "test");
	ros::NodeHandle n;


	//publisher
	ros::Publisher endEffPos_pub = n.advertise<geometry_msgs::Pose>("/EndEfforPose", 1);


//	robotPose.position.x = -0.523139;
//	robotPose.position.y = 0.480535;
//	robotPose.position.z = 0.792422;
//
//	robotPose.orientation.x = 0.390594;
//	robotPose.orientation.y = -0.009255;
//	robotPose.orientation.z = 0.004662;
//	robotPose.orientation.w = 0.920505;
	robotPose.position.x = 0.000682;
	robotPose.position.y = -0.000292;
	robotPose.position.z = 1.66;

	robotPose.orientation.x = 0;
	robotPose.orientation.y = -1.;
	robotPose.orientation.z = 0.0;
	robotPose.orientation.w = 0.0;

	while (n.ok())
	{
		endEffPos_pub.publish(robotPose);
		ROS_INFO("Position: %5f   %5f   %5f",robotPose.position.x,robotPose.position.y,robotPose.position.z);
		ROS_INFO("Orientation: %5f   %5f   %5f    %5f",robotPose.orientation.x,robotPose.orientation.y,robotPose.orientation.z,robotPose.orientation.w);
		usleep(5000);
		ros::spinOnce();
	}
}

