#include <ros/ros.h>

#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Pose.h>

#include <kinematics_msgs/GetKinematicSolverInfo.h>
#include <kinematics_msgs/GetPositionFK.h>
#include <kinematics_msgs/GetPositionIK.h>

#include <kdl/frames.hpp>

#include <visualization_msgs/Marker.h>

const unsigned int N_DOF = 7;
int j;
// define the service messages
kinematics_msgs::GetKinematicSolverInfo::Request request;
kinematics_msgs::GetKinematicSolverInfo::Response response;
// define the service messages
kinematics_msgs::GetPositionFK::Request  fk_request;
kinematics_msgs::GetPositionFK::Response fk_response;

ros::ServiceClient query_client;
ros::ServiceClient fk_client;

//struct Pose
//{
//	KDL::Vector position;
//	KDL::Rotation orientation;
//}robotPose;

sensor_msgs::JointState robotJoints;
visualization_msgs::Marker robotPoseMarker;
geometry_msgs::Pose robotPose;
void getFK_Info()
{
	if(query_client.call(request,response))
	{
		for(unsigned int i=0;
				i< response.kinematic_solver_info.joint_names.size(); i++)
		{
			ROS_INFO("Joint: %d %s", i,
					response.kinematic_solver_info.joint_names[i].c_str());
		}
	}
	else
	{
		ROS_ERROR("Could not call query service");
		ros::shutdown();
		exit(1);
	}
}

void getFK()
{
	fk_request.header.frame_id = "base_link";
	fk_request.fk_link_names.resize(1);
	fk_request.fk_link_names[0] = "arm_7_link";

	fk_request.robot_state.joint_state.position.resize(response.kinematic_solver_info.joint_names.size());
	fk_request.robot_state.joint_state.name =response.kinematic_solver_info.joint_names;

	for(unsigned int i=0;i< response.kinematic_solver_info.joint_names.size(); i++)
	{
		fk_request.robot_state.joint_state.position[i] = robotJoints.position[i];
	}
	if(fk_client.call(fk_request, fk_response))
	{
		if(fk_response.error_code.val == fk_response.error_code.SUCCESS)
		{
		//	robotPose.pose.position =KDL::Vector(fk_response.pose_stamped[0].pose.position.x,fk_response.pose_stamped[0].pose.position.y,fk_response.pose_stamped[0].pose.position.z);
		robotPose.position = fk_response.pose_stamped[0].pose.position;
		robotPose.orientation = fk_response.pose_stamped[0].pose.orientation;
		//robotPose.pose.orientation = KDL::Rotation::Quaternion(fk_response.pose_stamped[0].pose.orientation.x,fk_response.pose_stamped[0].pose.orientation.y,fk_response.pose_stamped[0].pose.orientation.z,fk_response.pose_stamped[0].pose.orientation.w);
		}
		else
		{
			ROS_ERROR("Forward kinematics failed");
		}
	}
	else
	{
		ROS_ERROR("Forward kinematics service call failed");
	}

}

void jointStateCB(const sensor_msgs::JointState msg)
{
	robotJoints.position = msg.position;
}


int main(int argc, char **argv){
	ros::init (argc, argv, "get_fk");
	ros::NodeHandle n;


	// Subriber for joint states
	ros::Subscriber sub = n.subscribe("joint_states", 1000, jointStateCB);

	//publisher
	ros::Publisher pose_pub = n.advertise<geometry_msgs::Pose>("EndEfforPose", 1);
	ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("Marker", 1);

	// Set our initial shape type to be a sphere
	uint32_t shape = visualization_msgs::Marker::SPHERE;

	visualization_msgs::Marker marker;


	robotJoints.position.resize(N_DOF);

	ros::service::waitForService("/arm_m_chain_kinematics/get_fk_solver_info");
	ros::service::waitForService("/arm_m_chain_kinematics/get_fk");


	query_client =n.serviceClient<kinematics_msgs::GetKinematicSolverInfo>("/arm_m_chain_kinematics/get_fk_solver_info");
	fk_client = n.serviceClient	<kinematics_msgs::GetPositionFK>("/arm_m_chain_kinematics/get_fk");
	getFK_Info();

	while (n.ok())
	{
		getFK();
		ROS_INFO("Position: %5f %5f %5f",robotPose.position.x,robotPose.position.y,robotPose.position.z);
		ROS_INFO("Orientation: %5f %5f %5f %5f",robotPose.orientation.x,robotPose.orientation.y,robotPose.orientation.z,robotPose.orientation.w);

		marker.header.frame_id = "/base_link";
		marker.header.stamp = ros::Time::now();
		marker.ns = "basic_shapes";
		marker.id = 0;
		marker.type = shape;

		marker.action = visualization_msgs::Marker::ADD;
		marker.pose.position.x = robotPose.position.x;
		marker.pose.position.y = robotPose.position.y;
		marker.pose.position.z = robotPose.position.z;
		marker.pose.orientation.x = robotPose.orientation.x;
		marker.pose.orientation.y = robotPose.orientation.y;
		marker.pose.orientation.z = robotPose.orientation.z;
		marker.pose.orientation.w = robotPose.orientation.w;

		// Set the scale of the marker -- 1x1x1 here means 1m on a side
		marker.scale.x = 0.05;
		marker.scale.y = 0.05;
		marker.scale.z = 0.05;

		marker.set_points_size(0.1);
		// Set the color -- be sure to set alpha to something non-zero!
		marker.color.r = 1.0f;
		marker.color.g = 0.0f;
		marker.color.b = 0.0f;
		marker.color.a = 1.0;

		marker.lifetime = ros::Duration();

		// Publish the marker
		pose_pub.publish(robotPose);
		marker_pub.publish(marker);

//		usleep(50000);
		ros::spinOnce();
	}
}

