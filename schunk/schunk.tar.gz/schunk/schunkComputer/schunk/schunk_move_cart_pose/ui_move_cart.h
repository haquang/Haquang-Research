/********************************************************************************
** Form generated from reading UI file 'move_cart.ui'
**
** Created: Sun Feb 5 17:49:29 2012
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOVE_CART_H
#define UI_MOVE_CART_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_MoveCart
{
public:
    QPushButton *btInit;
    QPushButton *btStop;
    QRadioButton *rdY;
    QRadioButton *rdZ;
    QRadioButton *rdRoll;
    QRadioButton *rdPitch;
    QRadioButton *rdYaw;
    QRadioButton *rdX;
    QLineEdit *txtX;
    QLineEdit *txtY;
    QLineEdit *txtZ;
    QLineEdit *txtRoll;
    QLineEdit *txtPitch;
    QLineEdit *txtYaw;
    QPushButton *BtUp;
    QPushButton *btDown;
    QLineEdit *txtPitch_2;
    QLineEdit *txtX_2;
    QLineEdit *txtRoll_2;
    QLineEdit *txtYaw_2;
    QLineEdit *txtY_2;
    QLineEdit *txtZ_2;
    QLabel *lbref;
    QLabel *label;
    QPushButton *btConfirm;
    QLineEdit *txt_jointPos_0;
    QLineEdit *txt_jointPos_1;
    QLineEdit *txt_jointPos_2;
    QLineEdit *txt_jointPos_3;
    QLineEdit *txt_jointPos_4;
    QLineEdit *txt_jointPos_5;
    QLineEdit *txt_jointPos_6;
    QLabel *label_2;
    QButtonGroup *buttonGroup;

    void setupUi(QDialog *MoveCart)
    {
        if (MoveCart->objectName().isEmpty())
            MoveCart->setObjectName(QString::fromUtf8("MoveCart"));
        MoveCart->resize(910, 474);
        btInit = new QPushButton(MoveCart);
        btInit->setObjectName(QString::fromUtf8("btInit"));
        btInit->setGeometry(QRect(20, 10, 93, 27));
        btStop = new QPushButton(MoveCart);
        btStop->setObjectName(QString::fromUtf8("btStop"));
        btStop->setGeometry(QRect(20, 40, 93, 27));
        rdY = new QRadioButton(MoveCart);
        buttonGroup = new QButtonGroup(MoveCart);
        buttonGroup->setObjectName(QString::fromUtf8("buttonGroup"));
        buttonGroup->addButton(rdY);
        rdY->setObjectName(QString::fromUtf8("rdY"));
        rdY->setGeometry(QRect(290, 90, 109, 22));
        rdZ = new QRadioButton(MoveCart);
        buttonGroup->addButton(rdZ);
        rdZ->setObjectName(QString::fromUtf8("rdZ"));
        rdZ->setGeometry(QRect(290, 140, 109, 22));
        rdRoll = new QRadioButton(MoveCart);
        buttonGroup->addButton(rdRoll);
        rdRoll->setObjectName(QString::fromUtf8("rdRoll"));
        rdRoll->setGeometry(QRect(290, 190, 109, 22));
        rdPitch = new QRadioButton(MoveCart);
        buttonGroup->addButton(rdPitch);
        rdPitch->setObjectName(QString::fromUtf8("rdPitch"));
        rdPitch->setGeometry(QRect(290, 230, 109, 22));
        rdYaw = new QRadioButton(MoveCart);
        buttonGroup->addButton(rdYaw);
        rdYaw->setObjectName(QString::fromUtf8("rdYaw"));
        rdYaw->setGeometry(QRect(290, 280, 109, 22));
        rdX = new QRadioButton(MoveCart);
        buttonGroup->addButton(rdX);
        rdX->setObjectName(QString::fromUtf8("rdX"));
        rdX->setGeometry(QRect(290, 40, 109, 22));
        txtX = new QLineEdit(MoveCart);
        txtX->setObjectName(QString::fromUtf8("txtX"));
        txtX->setGeometry(QRect(550, 30, 151, 27));
        txtY = new QLineEdit(MoveCart);
        txtY->setObjectName(QString::fromUtf8("txtY"));
        txtY->setGeometry(QRect(550, 80, 151, 27));
        txtZ = new QLineEdit(MoveCart);
        txtZ->setObjectName(QString::fromUtf8("txtZ"));
        txtZ->setGeometry(QRect(550, 120, 151, 27));
        txtRoll = new QLineEdit(MoveCart);
        txtRoll->setObjectName(QString::fromUtf8("txtRoll"));
        txtRoll->setGeometry(QRect(550, 170, 151, 27));
        txtPitch = new QLineEdit(MoveCart);
        txtPitch->setObjectName(QString::fromUtf8("txtPitch"));
        txtPitch->setGeometry(QRect(550, 220, 151, 27));
        txtYaw = new QLineEdit(MoveCart);
        txtYaw->setObjectName(QString::fromUtf8("txtYaw"));
        txtYaw->setGeometry(QRect(550, 270, 151, 27));
        BtUp = new QPushButton(MoveCart);
        BtUp->setObjectName(QString::fromUtf8("BtUp"));
        BtUp->setGeometry(QRect(160, 10, 93, 27));
        btDown = new QPushButton(MoveCart);
        btDown->setObjectName(QString::fromUtf8("btDown"));
        btDown->setGeometry(QRect(160, 40, 93, 27));
        txtPitch_2 = new QLineEdit(MoveCart);
        txtPitch_2->setObjectName(QString::fromUtf8("txtPitch_2"));
        txtPitch_2->setGeometry(QRect(410, 220, 113, 27));
        txtX_2 = new QLineEdit(MoveCart);
        txtX_2->setObjectName(QString::fromUtf8("txtX_2"));
        txtX_2->setGeometry(QRect(410, 30, 113, 27));
        txtRoll_2 = new QLineEdit(MoveCart);
        txtRoll_2->setObjectName(QString::fromUtf8("txtRoll_2"));
        txtRoll_2->setGeometry(QRect(410, 170, 113, 27));
        txtYaw_2 = new QLineEdit(MoveCart);
        txtYaw_2->setObjectName(QString::fromUtf8("txtYaw_2"));
        txtYaw_2->setGeometry(QRect(410, 270, 113, 27));
        txtY_2 = new QLineEdit(MoveCart);
        txtY_2->setObjectName(QString::fromUtf8("txtY_2"));
        txtY_2->setGeometry(QRect(410, 80, 113, 27));
        txtZ_2 = new QLineEdit(MoveCart);
        txtZ_2->setObjectName(QString::fromUtf8("txtZ_2"));
        txtZ_2->setGeometry(QRect(410, 120, 113, 27));
        lbref = new QLabel(MoveCart);
        lbref->setObjectName(QString::fromUtf8("lbref"));
        lbref->setGeometry(QRect(450, 0, 31, 21));
        label = new QLabel(MoveCart);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(580, 0, 62, 17));
        btConfirm = new QPushButton(MoveCart);
        btConfirm->setObjectName(QString::fromUtf8("btConfirm"));
        btConfirm->setGeometry(QRect(160, 110, 93, 27));
        txt_jointPos_0 = new QLineEdit(MoveCart);
        txt_jointPos_0->setObjectName(QString::fromUtf8("txt_jointPos_0"));
        txt_jointPos_0->setGeometry(QRect(720, 30, 151, 27));
        txt_jointPos_1 = new QLineEdit(MoveCart);
        txt_jointPos_1->setObjectName(QString::fromUtf8("txt_jointPos_1"));
        txt_jointPos_1->setGeometry(QRect(720, 80, 151, 27));
        txt_jointPos_2 = new QLineEdit(MoveCart);
        txt_jointPos_2->setObjectName(QString::fromUtf8("txt_jointPos_2"));
        txt_jointPos_2->setGeometry(QRect(720, 120, 151, 27));
        txt_jointPos_3 = new QLineEdit(MoveCart);
        txt_jointPos_3->setObjectName(QString::fromUtf8("txt_jointPos_3"));
        txt_jointPos_3->setGeometry(QRect(720, 170, 151, 27));
        txt_jointPos_4 = new QLineEdit(MoveCart);
        txt_jointPos_4->setObjectName(QString::fromUtf8("txt_jointPos_4"));
        txt_jointPos_4->setGeometry(QRect(720, 220, 151, 27));
        txt_jointPos_5 = new QLineEdit(MoveCart);
        txt_jointPos_5->setObjectName(QString::fromUtf8("txt_jointPos_5"));
        txt_jointPos_5->setGeometry(QRect(720, 270, 151, 27));
        txt_jointPos_6 = new QLineEdit(MoveCart);
        txt_jointPos_6->setObjectName(QString::fromUtf8("txt_jointPos_6"));
        txt_jointPos_6->setGeometry(QRect(720, 310, 151, 27));
        label_2 = new QLabel(MoveCart);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(750, 0, 71, 17));

        retranslateUi(MoveCart);

        QMetaObject::connectSlotsByName(MoveCart);
    } // setupUi

    void retranslateUi(QDialog *MoveCart)
    {
        MoveCart->setWindowTitle(QApplication::translate("MoveCart", "Dialog", 0, QApplication::UnicodeUTF8));
        btInit->setText(QApplication::translate("MoveCart", "Init", 0, QApplication::UnicodeUTF8));
        btStop->setText(QApplication::translate("MoveCart", "Stop", 0, QApplication::UnicodeUTF8));
        rdY->setText(QApplication::translate("MoveCart", "Y", 0, QApplication::UnicodeUTF8));
        rdZ->setText(QApplication::translate("MoveCart", "Z", 0, QApplication::UnicodeUTF8));
        rdRoll->setText(QApplication::translate("MoveCart", "Roll", 0, QApplication::UnicodeUTF8));
        rdPitch->setText(QApplication::translate("MoveCart", "Pitch", 0, QApplication::UnicodeUTF8));
        rdYaw->setText(QApplication::translate("MoveCart", "Yaw", 0, QApplication::UnicodeUTF8));
        rdX->setText(QApplication::translate("MoveCart", "X", 0, QApplication::UnicodeUTF8));
        BtUp->setText(QApplication::translate("MoveCart", "Up", 0, QApplication::UnicodeUTF8));
        btDown->setText(QApplication::translate("MoveCart", "Down", 0, QApplication::UnicodeUTF8));
        lbref->setText(QApplication::translate("MoveCart", "Ref", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MoveCart", "Current", 0, QApplication::UnicodeUTF8));
        btConfirm->setText(QApplication::translate("MoveCart", "Confirm", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MoveCart", "Joint Pos", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MoveCart: public Ui_MoveCart {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOVE_CART_H
