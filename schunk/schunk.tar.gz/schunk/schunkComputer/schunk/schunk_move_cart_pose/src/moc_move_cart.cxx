/****************************************************************************
** Meta object code from reading C++ file 'move_cart.h'
**
** Created: Fri Feb 17 13:47:59 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "move_cart.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'move_cart.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MoveCart[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x08,
      23,    9,    9,    9, 0x08,
      43,    9,    9,    9, 0x08,
      63,    9,    9,    9, 0x08,
      81,    9,    9,    9, 0x08,
      98,    9,    9,    9, 0x08,
     115,    9,    9,    9, 0x08,
     132,    9,    9,    9, 0x08,
     152,    9,    9,    9, 0x08,
     173,    9,    9,    9, 0x08,
     192,    9,    9,    9, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MoveCart[] = {
    "MoveCart\0\0update_pos()\0on_btInit_clicked()\0"
    "on_btStop_clicked()\0on_BtUp_clicked()\0"
    "on_rdX_clicked()\0on_rdY_clicked()\0"
    "on_rdZ_clicked()\0on_rdRoll_clicked()\0"
    "on_rdPitch_clicked()\0on_rdYaw_clicked()\0"
    "on_btDown_clicked()\0"
};

const QMetaObject MoveCart::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_MoveCart,
      qt_meta_data_MoveCart, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MoveCart::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MoveCart::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MoveCart::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MoveCart))
        return static_cast<void*>(const_cast< MoveCart*>(this));
    return QDialog::qt_metacast(_clname);
}

int MoveCart::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: update_pos(); break;
        case 1: on_btInit_clicked(); break;
        case 2: on_btStop_clicked(); break;
        case 3: on_BtUp_clicked(); break;
        case 4: on_rdX_clicked(); break;
        case 5: on_rdY_clicked(); break;
        case 6: on_rdZ_clicked(); break;
        case 7: on_rdRoll_clicked(); break;
        case 8: on_rdPitch_clicked(); break;
        case 9: on_rdYaw_clicked(); break;
        case 10: on_btDown_clicked(); break;
        default: ;
        }
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
