#ifndef QNODE_H
#define QNODE_H

#define signalslib signals
#define signals signals

#include <iostream>
#include <vector>

#include <ros/ros.h>
#include <cob_srvs/Trigger.h>

#include <pr2_controllers_msgs/JointTrajectoryAction.h>
#include <pr2_controllers_msgs/JointTrajectoryControllerState.h>

#include <trajectory_msgs/JointTrajectory.h>
#include <actionlib/client/simple_action_client.h>


#include <boost/thread.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <kinematics_msgs/GetKinematicSolverInfo.h>
#include <kinematics_msgs/GetPositionFK.h>
#include <kinematics_msgs/GetPositionIK.h>

#include <kdl/frames.hpp>
#include <tf/transform_listener.h>
#include <tf_conversions/tf_kdl.h>

#include <sensor_msgs/JointState.h>

#include <std_msgs/String.h>

#include <QThread>

typedef enum  {Init, Stop, Recover} ActionMode;
typedef enum  {Position, Velocity} OperationMode;


typedef actionlib::SimpleActionClient< pr2_controllers_msgs::JointTrajectoryAction > TrajClient;



#define NJoint  7    // 7 DOF

class RobotPose
{
public:
        KDL::Vector pos;
        KDL::Rotation rot;

        RobotPose()
        {
                pos = KDL::Vector::Zero();
                rot = KDL::Rotation::Identity();
        }
        RobotPose(const KDL::Vector &pos, const KDL::Rotation &rot)
        {
                this->pos = pos;
                this->rot = rot;
        }
        void Print(const std::string &name)
        {
                ROS_INFO("--------POS %s--------",name.c_str());
                ROS_INFO("Position: x = %f, y = %f, z= %f",pos.x(), pos.y(), pos.z());
                double x, y, z, w;
                rot.GetQuaternion(x, y, z, w);
                ROS_INFO("Quaternion: x = %f, y = %f, z= %f, w = %f  ", x, y, z, w );
                ROS_INFO("--------------------- ");
        }
};

class RobotJoint
{
public:
        std::vector<std::string> names;
        std::vector<double> angles;
        RobotJoint()
        {
                names.resize(NJoint);
                angles.resize(NJoint);
                names[0] = "arm_1_joint";
                names[1] = "arm_2_joint";
                names[2] = "arm_3_joint";
                names[3] = "arm_4_joint";
                names[4] = "arm_5_joint";
                names[5] = "arm_6_joint";
                names[6] = "arm_7_joint";
                angles[0] = 0.0;
                angles[1] = 0.0;
                angles[2] = 0.0;
                angles[3] = 0.0;
                angles[4] = 0.0;
                angles[5] = 0.0;
                angles[6] = 0.0;

        }
        RobotJoint(const double &q1,const double &q2, const double &q3, const double &q4, const double &q5, const double &q6, const double &q7)
        {
                names.resize(NJoint);
                angles.resize(NJoint);
                names[0] = "arm_1_joint";
                names[1] = "arm_2_joint";
                names[2] = "arm_3_joint";
                names[3] = "arm_4_joint";
                names[4] = "arm_5_joint";
                names[5] = "arm_6_joint";
                names[6] = "arm_7_joint";
                angles[0] = q1;
                angles[1] = q2;
                angles[2] = q3;
                angles[3] = q4;
                angles[4] = q5;
                angles[5] = q6;
                angles[6] = q7;
        }
        void Print()
        {
                ROS_INFO("----------ROBOT JOINTS--------------");
                for(unsigned int i = 0; i < names.size(); i++)
                {
                        ROS_INFO("%s : %f",names[i].c_str(), angles[i]);
                }
                ROS_INFO("------------------------------------");
        }
};


class RobotKinematics
{
public:
        RobotKinematics()
        {
                ros::service::waitForService("/schunk_kinematics/get_fk_solver_info");
                ros::service::waitForService("/schunk_kinematics/get_fk");

                ros::service::waitForService("/schunk_kinematics/get_ik_solver_info");
                ros::service::waitForService("/schunk_kinematics/get_ik");

                query_fk_info = nh.serviceClient<kinematics_msgs::GetKinematicSolverInfo>("/schunk_kinematics/get_fk_solver_info");
                fk_client = nh.serviceClient<kinematics_msgs::GetPositionFK>("/schunk_kinematics/get_fk");

                query_ik_info = nh.serviceClient<kinematics_msgs::GetKinematicSolverInfo>("/schunk_kinematics/get_ik_solver_info");
                ik_client  =  nh.serviceClient<kinematics_msgs::GetPositionIK>("/schunk_kinematics/get_ik");

                getKinematicSolverInfo();
        }

    bool getFK(const RobotJoint &rb_joint, RobotPose &rb_eff)
        {
                kinematics_msgs::GetPositionFK::Request fk_req;
                kinematics_msgs::GetPositionFK::Response fk_res;
                fk_req.header.frame_id  = "base_link";
                fk_req.fk_link_names.resize(1);
                fk_req.fk_link_names[0] = "arm_7_link";
                fk_req.robot_state.joint_state.position.resize(fk_res_info.kinematic_solver_info.joint_names.size());
                fk_req.robot_state.joint_state.name = fk_res_info.kinematic_solver_info.joint_names;
                for(unsigned int i = 0; i < fk_res_info.kinematic_solver_info.joint_names.size(); i++)
                {
                        fk_req.robot_state.joint_state.position[i] = rb_joint.angles[i];
                }

                if(fk_client.call(/*arm_7_lifk_req*/fk_req,fk_res))
                {
                          if(fk_res.error_code.val == fk_res.error_code.SUCCESS)
                           {
                                 for(unsigned int i=0; i < fk_res.pose_stamped.size(); i ++)
                                 {
                                   ROS_INFO_STREAM("Link    : " << fk_res.fk_link_names[i].c_str());
                                   ROS_INFO_STREAM("Position: " <<
                                         fk_res.pose_stamped[i].pose.position.x << "," <<
                                         fk_res.pose_stamped[i].pose.position.y << "," <<
                                         fk_res.pose_stamped[i].pose.position.z);
                                   ROS_INFO("Orientation: %f %f %f %f",
                                   //arm_7_lifk_res.pose_stamped[i].pose.orientation.x,
                                         fk_res.pose_stamped[i].pose.orientation.x,
                                         fk_res.pose_stamped[i].pose.orientation.y,
                                         fk_res.pose_stamped[i].pose.orientation.z,
                                         fk_res.pose_stamped[i].pose.orientation.w);

                                 }
                                 //There only one result :D
                                 rb_eff.pos   = KDL::Vector(fk_res.pose_stamped[0].pose.position.x, fk_res.pose_stamped[0].pose.position.y, fk_res.pose_stamped[0].pose.position.z);
                                 rb_eff.rot   = KDL::Rotation::Quaternion(fk_res.pose_stamped[0].pose.orientation.x, fk_res.pose_stamped[0].pose.orientation.y,
                                                                                   fk_res.pose_stamped[0].pose.orientation.z,fk_res.pose_stamped[0].pose.orientation.w);
                                 return true;
                           }
                           else
                           {
                                 ROS_ERROR("Forward kinematics failed");
                                 return false;
                           }

                }
                else
                {
                        ROS_ERROR("Call FK solver failed");
                        return false;
                }
        }
        bool getIK(RobotJoint &rb_joint,const RobotPose &rb_eff)
        {
                kinematics_msgs::GetPositionIK::Request  ik_req;
                kinematics_msgs::GetPositionIK::Response ik_res;
                ik_req.timeout = ros::Duration(5.0);
                ik_req.ik_request.ik_link_name = "arm_7_link";
                ik_req.ik_request.pose_stamped.header.frame_id = "base_link";
                ik_req.ik_request.pose_stamped.pose.position.x = rb_eff.pos.x();
                ik_req.ik_request.pose_stamped.pose.position.y = rb_eff.pos.y();
                ik_req.ik_request.pose_stamped.pose.position.z = rb_eff.pos.z();

                rb_eff.rot.GetQuaternion(ik_req.ik_request.pose_stamped.pose.orientation.x,ik_req.ik_request.pose_stamped.pose.orientation.y,
                                                                 ik_req.ik_request.pose_stamped.pose.orientation.z,ik_req.ik_request.pose_stamped.pose.orientation.w );

                ik_req.ik_request.ik_seed_state.joint_state.position.resize(ik_res_info.kinematic_solver_info.joint_names.size());
                ik_req.ik_request.ik_seed_state.joint_state.name = ik_res_info.kinematic_solver_info.joint_names;

                for(unsigned int i = 0; i < ik_res_info.kinematic_solver_info.joint_names.size(); i++)
                {
                        ik_req.ik_request.ik_seed_state.joint_state.position[i] = (ik_res_info.kinematic_solver_info.limits[i].min_position + ik_res_info.kinematic_solver_info.limits[i].max_position)/2.0;
                }
                if(ik_client.call(ik_req,ik_res))
                {
                        if(ik_res.error_code.val == ik_res.error_code.SUCCESS)
                        {
                                for(unsigned int i = 0; i < ik_res.solution.joint_state.name.size(); i++)
                                {
                                         ROS_INFO("Joint: %s %f",ik_res.solution.joint_state.name[i].c_str(),ik_res.solution.joint_state.position[i]);
                                         rb_joint.angles[i] = ik_res.solution.joint_state.position[i];
                                }

                                return true;
                        }
                        else
                        {
                                ROS_ERROR("Inverse kinematics failed");
                                return false;
                        }

                }
                else
                {
                        ROS_ERROR("Inverse kinematics service call failed");
                        return false;
                }

        }
        void getKinematicSolverInfo()
        {
                kinematics_msgs::GetKinematicSolverInfo::Request request;

                ROS_INFO("----------FK--------");
                if(query_fk_info.call(request,fk_res_info))
                {
                        for(unsigned int i  = 0; i < fk_res_info.kinematic_solver_info.joint_names.size(); i++)
                        {
                                ROS_INFO("Joint: %d %s",i,fk_res_info.kinematic_solver_info.joint_names[i].c_str());
                        }
                }
                else
                {
                        ROS_ERROR("Could Query for FK Solver Info");
                }

                ROS_INFO("----------IK--------");
                if(query_ik_info.call(request,ik_res_info))
                {
                        for(unsigned int i  = 0; i < ik_res_info.kinematic_solver_info.joint_names.size(); i++)
                        {
                                ROS_INFO("Joint: %d %s",i,ik_res_info.kinematic_solver_info.joint_names[i].c_str());
                        }
                }
                else
                {
                        ROS_ERROR("Could Query for IK Solver Info");
                }

        }
private:
        ros::NodeHandle nh;
        ros::ServiceClient query_ik_info;
        ros::ServiceClient query_fk_info;
        ros::ServiceClient fk_client;
        ros::ServiceClient ik_client;
        kinematics_msgs::GetKinematicSolverInfo::Response ik_res_info;
        kinematics_msgs::GetKinematicSolverInfo::Response fk_res_info;

};

class Qnode:public QThread
{
public:
    double jointVar[NJoint];
    double currentPos[NJoint];
    std::string joint_name[NJoint];
    int m_mode;

    static const double jointMin = -3.14;
    static const double jointMax =  3.14;

    Qnode(int argc, char** argv);

    ~Qnode();

    void init();
    void run();
    \
    bool initJoint();
    bool stopJoint();
    bool recoverJoint();
    bool changeJointOperationMode(const OperationMode &mode);
    double satuation(const double &angle);

    void sendDeltaPose(const RobotPose &delta_Pose);
    RobotPose getCurrentPose(); // check.if can't get currentpose
    RobotJoint m_joint;
    RobotPose m_gpos;


    void sendCommand();
    void init_J(const int JointID);
    void jointcallback(const sensor_msgs::JointStateConstPtr& msg);
    void chatterCallback(const std_msgs::String::ConstPtr& msg);


private:
    int     init_argc;
    char**  init_argv;
    ros::NodeHandle nh;

    tf::TransformListener listener;
    tf::StampedTransform transform;

    ros::Publisher  command_pub;
    ros::ServiceClient init_client;
    ros::ServiceClient stop_client;
    ros::ServiceClient recover_client;
    ros::ServiceClient operation_client;

    ros::Subscriber sub_joint_states;

    boost::thread t;
    TrajClient *traj_client_;


    RobotKinematics rb_kinematics;
};

#endif // QNODE_H
