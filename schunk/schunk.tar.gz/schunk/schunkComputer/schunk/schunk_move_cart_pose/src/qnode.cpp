#include "qnode.h"

Qnode::Qnode(int argc, char** argv)
{
    init_argc = argc;
    init_argv = argv;

    jointVar[0] = 0.0;
    jointVar[1] = 0.5;
    jointVar[2] = 0.0;
    jointVar[3] = 0.5;
    jointVar[4] = 0.0;
    jointVar[5] = 1.2;
    jointVar[6] = 0.5;
    currentPos[0]=0.0;
    currentPos[1]=0.5;
    currentPos[2]=0.0;
    currentPos[3]=0.5;
    currentPos[4]=0.0;
    currentPos[5]=1.2;
    currentPos[6]=0.5;

    joint_name[0]  = "arm_1_joint";
    joint_name[1]  = "arm_2_joint";
    joint_name[2]  = "arm_3_joint";
    joint_name[3]  = "arm_4_joint";
    joint_name[4]  = "arm_5_joint";
    joint_name[5]  = "arm_6_joint";
    joint_name[6]  = "arm_7_joint";


    m_mode=0; //X,Y,Z,RPY

}


void Qnode::init()
{
    ros::init(init_argc, init_argv,"move_cart");

    ros::start();          // our node handles go out of scope, so we want to control shutdown explicitly.

    start();

    command_pub  = nh.advertise<trajectory_msgs::JointTrajectory>("/schunk_controller/command",1);
    init_client  = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/init");
    stop_client  = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/stop");
    recover_client = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/recover");
    operation_client = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/set_operation_mode");
    sub_joint_states = nh.subscribe ("joint_states",3, &Qnode::jointcallback, this);


//    topicPub_JointState_ = n_.advertise<sensor_msgs::JointState>("/joint_states", 1);
//    topicPub_ControllerState_ = n_.advertise<pr2_controllers_msgs::JointTrajectoryControllerState>("state", 1);

    //t = boost::thread(boost::bind(&Qnode::sendCommand, this));
    traj_client_ = new TrajClient("/schunk_controller/joint_trajectory_action", true);


    // wait for action server to come up
    while(!traj_client_->waitForServer(ros::Duration(5.0)))
    {
        ROS_INFO("Waiting for the joint_trajectory_action server");
    }
    for(int i=0;i<NJoint;i++) m_joint.angles[i]=currentPos[i];
    if(rb_kinematics.getFK(m_joint,m_gpos) == false)ROS_ERROR("FK ERROR");
}

void Qnode::run()
{



}
Qnode::~Qnode()
{
    ros::shutdown();
    std::cout  << "Waiting for ros thread to finish..." << std::endl;
    t.join();
    wait();
    delete traj_client_;
}

bool Qnode::initJoint()
{
    cob_srvs::Trigger  srv;



    if(!init_client.call(srv))
    {
        ROS_INFO("%s", srv.response.error_message);
        return false;
    }
    else
    {
        ROS_INFO("Init Joint Success");
        return true;
    }
}
bool Qnode::stopJoint()
{
    cob_srvs::Trigger  srv;
    if(!stop_client.call(srv))
    {
        ROS_INFO("%s", srv.response.error_message);
        return false;
    }
    else
    {
        ROS_INFO("Stop Joint Success");
        return true;
    }

}


bool Qnode::recoverJoint()
{
    cob_srvs::Trigger  srv;
    if(!recover_client.call(srv))
    {
        ROS_INFO("%s", srv.response.error_message);
        return false;
    }
    else
    {
        ROS_INFO("Recover Joint Success");
        return true;
    }
}

double Qnode::satuation(const double &angle)
{
    double temp = angle;
    if(angle  > jointMax)
    {
        temp = jointMax;
    }
    if(angle < jointMin)
    {
        temp = jointMin;
    }
    return temp;
}

void Qnode::init_J(const int JointID)  // 0 ,1, 2, 3, 4, 5, 6
{
    if(JointID > 6 )
    {
        return;
    }
    else if(JointID < 0)
    {
        return;
    }
    pr2_controllers_msgs::JointTrajectoryGoal goal;


    goal.trajectory.header.stamp = ros::Time::now();
    goal.trajectory.header.frame_id  = "/base_link";
    goal.trajectory.joint_names.push_back(joint_name[0]);
    goal.trajectory.joint_names.push_back(joint_name[1]);
    goal.trajectory.joint_names.push_back(joint_name[2]);
    goal.trajectory.joint_names.push_back(joint_name[3]);
    goal.trajectory.joint_names.push_back(joint_name[4]);
    goal.trajectory.joint_names.push_back(joint_name[5]);
    goal.trajectory.joint_names.push_back(joint_name[6]);

    goal.trajectory.points.resize(1);
    goal.trajectory.points[0].positions.resize(NJoint);

//    for(int i = 0; i < NJoint; i++ )
//    {
//        if(i == JointID)
//        {
//            goal.trajectory.points[0].positions[i]  = 1.0;
//        }
//        else
//        {
//            goal.trajectory.points[0].positions[i]  = 1.0;
//        }
//    }

    goal.trajectory.points[0].positions[0]  = 0.0;
    goal.trajectory.points[0].positions[1]  = 0.5;
    goal.trajectory.points[0].positions[2]  = 0.0;
    goal.trajectory.points[0].positions[3]  = 0.5;
    goal.trajectory.points[0].positions[4]  = 0.0;
    goal.trajectory.points[0].positions[5]  = 1.2;
    goal.trajectory.points[0].positions[6]  = 0.0;

    goal.trajectory.points[0].velocities.resize(NJoint);

    for(int i = 0; i < NJoint; i++ )
    {
        goal.trajectory.points[0].velocities[i] = 0.0;
    }

    goal.trajectory.points[0].time_from_start = ros::Duration(0.0);
    traj_client_->sendGoal(goal);

    while(traj_client_->getState().isDone() && ros::ok())
    {
        usleep(50000);
    }

}


void Qnode::sendCommand()
{
    pr2_controllers_msgs::JointTrajectoryGoal goal;
    goal.trajectory.header.stamp = ros::Time::now();
    goal.trajectory.header.frame_id  = "/base_link";
    goal.trajectory.joint_names.push_back(joint_name[0]);
    goal.trajectory.joint_names.push_back(joint_name[1]);
    goal.trajectory.joint_names.push_back(joint_name[2]);
    goal.trajectory.joint_names.push_back(joint_name[3]);
    goal.trajectory.joint_names.push_back(joint_name[4]);
    goal.trajectory.joint_names.push_back(joint_name[5]);
    goal.trajectory.joint_names.push_back(joint_name[6]);

    goal.trajectory.points.resize(1);
    goal.trajectory.points[0].positions.resize(NJoint);

    for(int i = 0; i < NJoint; i++ )
    {

        goal.trajectory.points[0].positions[i]  = jointVar[i];
    }

    goal.trajectory.points[0].velocities.resize(NJoint);

    for(int i = 0; i < NJoint; i++ )
    {
        goal.trajectory.points[0].velocities[0] = 0.0;
    }

    goal.trajectory.points[0].time_from_start = ros::Duration(0.0);
    traj_client_->sendGoal(goal);

    while(traj_client_->getState().isDone() && ros::ok())
    {
        usleep(50000);
    }

}


void Qnode::sendDeltaPose(const RobotPose &delta_Pose)
{

}

void Qnode::jointcallback(const sensor_msgs::JointStateConstPtr& msg)

{
    for(int i=0;i<NJoint;i++) currentPos[i]=msg->position[i];
}


RobotPose Qnode::getCurrentPose()
{
    //for(int i=0;i<NJoint;i++) m_joint.angles[i]=currentPos[i];


    //if(rb_kinematics.getFK(m_joint,m_gpos) == false)ROS_ERROR("FK ERROR");

    if(rb_kinematics.getIK(m_joint,m_gpos) == false)ROS_ERROR("IK ERROR");
    else
    {
        for(int i=0; i<NJoint ; i++) jointVar[i]=m_joint.angles[i];
        if(traj_client_->getState().isDone() && ros::ok())sendCommand();
    }



    try
    {
        listener.lookupTransform("/base_link", "/arm_7_link",ros::Time(0), transform);
    }
    catch (tf::TransformException ex){
        ROS_ERROR("%s",ex.what());
    }

    ros::spinOnce();

    RobotPose m_pose;
    KDL::Frame m_frame;
    tf::Pose tf_pose;
    tf_pose.setOrigin(transform.getOrigin());
    tf_pose.setRotation(transform.getRotation());

    tf::PoseTFToKDL(tf_pose,m_frame);

    m_pose.pos  = m_frame.p;
    m_pose.rot  = m_frame.M;

    return m_pose;

}
