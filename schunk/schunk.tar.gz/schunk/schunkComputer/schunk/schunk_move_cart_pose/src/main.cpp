#include "move_cart.h"
#include <QApplication>
#include <QtGui>
#include <QThread>
#include <boost/thread/thread.hpp>
#include <ros/ros.h>


int main(int argc, char * argv[])
{
    ros::init(argc, argv, "move_joint");
    ros::NodeHandle nh;


    tf::TransformListener listener;
    tf::StampedTransform transform;

    QApplication a(argc, argv);
    MoveCart w(argc, argv);
    w.show();

    a.connect(&a, SIGNAL(lastWindowClosed()), &a, SLOT(quit()));
    int result = a.exec();
    return result;

}
