#ifndef MOVE_CART_H
#define MOVE_CART_H

#include <QDialog>
#include "qnode.h"
#include <QTimer>
#include <QTime>

namespace Ui {
    class MoveCart;
}

class MoveCart : public QDialog
{
    Q_OBJECT

public:
    explicit MoveCart(int argc,char ** argv,QWidget *parent = 0);

    ~MoveCart();

private slots:
    void update_pos();
    void on_btInit_clicked();


    void on_btStop_clicked();

    void on_BtUp_clicked();

    void on_rdX_clicked();

    void on_rdY_clicked();

    void on_rdZ_clicked();

    void on_rdRoll_clicked();

    void on_rdPitch_clicked();

    void on_rdYaw_clicked();

    void on_btDown_clicked();

private:
    Ui::MoveCart *ui;
    Qnode qnode;
    RobotPose m_cpose;
    double roll, pitch , yaw;
};


#endif // MOVE_CART_H
