#include "move_cart.h"
#include "ui_move_cart.h"
#include <QMessageBox>


MoveCart::MoveCart(int argc,char ** argv,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MoveCart),
    qnode(argc, argv)
{
    ui->setupUi(this);

    //Init

    qnode.init();

    roll = 0;
    pitch = 0;
    yaw = 0;

    QMessageBox msgbox;

    QString msg = QString::number(roll);
    msgbox.setText(msg);
    msgbox.exec();

    QTimer *timer = new QTimer;
        connect(timer,SIGNAL(timeout()),this, SLOT(update_pos()));
    timer->start(10);


}

MoveCart::~MoveCart()
{
    delete ui;
}

void MoveCart::on_btInit_clicked()
{
    qnode.initJoint();
    qnode.init_J(0);
}

void MoveCart::update_pos()
{
    RobotPose m_pose = qnode.getCurrentPose();

    ui->txtX->setText(QString::number(m_pose.pos.x()));
    ui->txtY->setText(QString::number(m_pose.pos.y()));
    ui->txtZ->setText(QString::number(m_pose.pos.z()));


    m_pose.rot.GetRPY(roll, pitch, yaw);

    ui->txtRoll->setText(QString::number(roll));
    ui->txtPitch->setText(QString::number(pitch));
    ui->txtYaw->setText(QString::number(yaw));



    ui->txt_jointPos_0->setText(QString::number(qnode.currentPos[0]));
    ui->txt_jointPos_1->setText(QString::number(qnode.currentPos[1]));
    ui->txt_jointPos_2->setText(QString::number(qnode.currentPos[2]));
    ui->txt_jointPos_3->setText(QString::number(qnode.currentPos[3]));
    ui->txt_jointPos_4->setText(QString::number(qnode.currentPos[4]));
    ui->txt_jointPos_5->setText(QString::number(qnode.currentPos[5]));
    ui->txt_jointPos_6->setText(QString::number(qnode.currentPos[6]));
}

void MoveCart::on_btStop_clicked()
{
    qnode.stopJoint();
}

void MoveCart::on_BtUp_clicked()
{
    QMessageBox msgbox;
    QString msg;
    msg = "I'm here";

    msgbox.setText(msg);

    //msgbox.exec();

     m_cpose = qnode.m_gpos;



   if(qnode.m_mode == 0) qnode.m_gpos.pos.x(m_cpose.pos.x()+0.01);
   else if(qnode.m_mode == 1)qnode.m_gpos.pos.y(m_cpose.pos.y()+0.01);
   else if(qnode.m_mode == 2) qnode.m_gpos.pos.z(m_cpose.pos.z()+0.01);


   else if(qnode.m_mode == 3) {
       m_cpose.rot.GetRPY(roll,pitch,yaw);
       roll += 0.1;
  //     qnode.m_gpos.rot.RPY(roll,pitch,yaw);
       msg = QString::number(roll);
       msgbox.setText(msg);
       msgbox.exec();
   }

   else if(qnode.m_mode == 4) {
       pitch += 0.1;
       qnode.m_gpos.rot.RPY(roll,pitch,yaw);
      // qnode.m_gpos.rot.
       //msgbox.exec();
   }

   else if(qnode.m_mode == 5) {
       yaw += 0.1;
       qnode.m_gpos.rot.RPY(roll,pitch,yaw);
      // msgbox.exec();
   }

}
void MoveCart::on_btDown_clicked()
{

   m_cpose = qnode.m_gpos;
   double roll, pitch , yaw;
   qnode.m_gpos.rot.GetRPY(roll,pitch,yaw);

  if(qnode.m_mode == 0) qnode.m_gpos.pos.x(m_cpose.pos.x()-0.01);
  else if(qnode.m_mode == 1)qnode.m_gpos.pos.y(m_cpose.pos.y()-0.01);
  else if(qnode.m_mode == 2) qnode.m_gpos.pos.z(m_cpose.pos.z()-0.01);
  else if(qnode.m_mode == 3) {
      roll -= 0.1;

      qnode.m_gpos.rot.RPY(roll,pitch,yaw);


  }

  else if(qnode.m_mode == 4) {
      pitch -= 0.1;
      qnode.m_gpos.rot.RPY(roll,pitch,yaw);
  }

  else if(qnode.m_mode == 5) {
      yaw -= 0.1;
      qnode.m_gpos.rot.RPY(roll,pitch,yaw);

  }


}

void MoveCart::on_rdX_clicked()
{
    qnode.m_mode = 0;
}

void MoveCart::on_rdY_clicked()
{
     qnode.m_mode = 1;
}

void MoveCart::on_rdZ_clicked()
{
     qnode.m_mode = 2;
}

void MoveCart::on_rdRoll_clicked()
{
     qnode.m_mode = 3;
}

void MoveCart::on_rdPitch_clicked()
{
    qnode.m_mode = 4;
}

void MoveCart::on_rdYaw_clicked()
{
    qnode.m_mode = 5;
}


