export OGRE_RTT_MODE=FBO
rm -rf /tmp/gazeb*
roslaunch schunk_simulation sim1.launch
