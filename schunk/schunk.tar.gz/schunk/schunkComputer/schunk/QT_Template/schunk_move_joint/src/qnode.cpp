#include "qnode.h"

Qnode::Qnode(int argc, char** argv)
{
    init_argc = argc;
    init_argv = argv;
}
void Qnode::init()
{
    ros::init(init_argc, init_argv,"tele_gui");
    ros::start();          // our node handles go out of scope, so we want to control shutdown explicitly.
    ros::NodeHandle nh;
    start();

}

void Qnode::run()
{
    //ros::Rate loop_rate(1);
    ros::spin();
}
Qnode::~Qnode()
{
    ros::shutdown();
    std::cout  << "Waiting for ros thread to finish..." << std::endl;
    wait();
}
