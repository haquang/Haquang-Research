#ifndef MOVE_JOINT_H
#define MOVE_JOINT_H

#include <QMainWindow>
#include <sstream>
#include <string>
#include "qnode.h"

namespace Ui {
    class MoveJoint;
}

class MoveJoint : public QMainWindow {
    Q_OBJECT
public:
    explicit MoveJoint(int argc,char ** argv,QWidget *parent = 0);
    ~MoveJoint();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::MoveJoint *ui;
    Qnode qnode;
};

#endif // MOVE_JOINT_H
