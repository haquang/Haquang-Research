#ifndef QNODE_H
#define QNODE_H

#define signalslib signals
#define signals signals

#include <iostream>
#include <vector>

#include <ros/ros.h>
#include <QThread>

class Qnode:public QThread
{
public:
    Qnode(int argc, char** argv);
    ~Qnode();
    void init();
    void run();

private:
    int     init_argc;
    char**  init_argv;

};

#endif // QNODE_H
