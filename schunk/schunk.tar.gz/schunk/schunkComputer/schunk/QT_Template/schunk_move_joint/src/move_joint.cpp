#include "move_joint.h"
#include "ui_move_joint.h"

MoveJoint::MoveJoint(int argc, char** argv,QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MoveJoint),
    qnode(argc, argv)
{
    ui->setupUi(this);
}

MoveJoint::~MoveJoint()
{
    delete ui;
}

void MoveJoint::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
