/********************************************************************************
** Form generated from reading UI file 'move_joint.ui'
**
** Created: Wed Jan 11 19:10:09 2012
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOVE_JOINT_H
#define UI_MOVE_JOINT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MoveJoint
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MoveJoint)
    {
        if (MoveJoint->objectName().isEmpty())
            MoveJoint->setObjectName(QString::fromUtf8("MoveJoint"));
        MoveJoint->resize(800, 600);
        menubar = new QMenuBar(MoveJoint);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        MoveJoint->setMenuBar(menubar);
        centralwidget = new QWidget(MoveJoint);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        MoveJoint->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MoveJoint);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MoveJoint->setStatusBar(statusbar);

        retranslateUi(MoveJoint);

        QMetaObject::connectSlotsByName(MoveJoint);
    } // setupUi

    void retranslateUi(QMainWindow *MoveJoint)
    {
        MoveJoint->setWindowTitle(QApplication::translate("MoveJoint", "MainWindow", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MoveJoint: public Ui_MoveJoint {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOVE_JOINT_H
