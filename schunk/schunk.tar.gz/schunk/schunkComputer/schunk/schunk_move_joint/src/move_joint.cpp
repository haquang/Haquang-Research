#include "move_joint.h"
#include "ui_move_joint.h"


MoveJoint::MoveJoint(int argc, char** argv,QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MoveJoint),
    qnode(argc, argv)
{
    ui->setupUi(this);

    JointID  = 10000;

    //Init
    qnode.init();
}

MoveJoint::~MoveJoint()
{
    delete ui;
}

void MoveJoint::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void MoveJoint::on_btInit_clicked()
{
    if(qnode.initJoint())
    {
        this->ui->btInit->setEnabled(false);
        qnode.sendCommand(0);
    }

}

void MoveJoint::on_btStop_clicked()
{
    if(qnode.stopJoint())
    {

    }
}

void MoveJoint::on_btUp_clicked()
{
    qnode.jointVar[JointID]  =  qnode.jointVar[JointID] + 0.1;
    qnode.sendCommand(JointID);
}

void MoveJoint::on_btDown_clicked()
{
    qnode.jointVar[JointID]  =  qnode.jointVar[JointID] - 0.1;
    qnode.sendCommand(JointID);
}


void MoveJoint::on_rdJoint1_clicked()
{
    JointID = 0;
    this->ui->lbSchunk->setText("Controlling Joint 1");
}

void MoveJoint::on_rdJoint2_clicked()
{
    JointID = 1;
    this->ui->lbSchunk->setText("Controlling Joint 2");
}

void MoveJoint::on_rdJoint3_clicked()
{
    JointID = 2;
    this->ui->lbSchunk->setText("Controlling Joint 3");
}

void MoveJoint::on_rdJoint4_clicked()
{
    JointID = 3;
    this->ui->lbSchunk->setText("Controlling Joint 4");
}

void MoveJoint::on_rdJoint5_clicked()
{
    JointID = 4;
    this->ui->lbSchunk->setText("Controlling Joint 5");
}

void MoveJoint::on_rdJoint6_clicked()
{
    JointID = 5;
    this->ui->lbSchunk->setText("Controlling Joint 6");
}

void MoveJoint::on_rdJoint7_clicked()
{
    JointID = 6;
    this->ui->lbSchunk->setText("Controlling Joint 7");
}
