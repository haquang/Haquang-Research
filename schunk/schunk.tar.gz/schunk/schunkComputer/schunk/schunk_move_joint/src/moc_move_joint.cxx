/****************************************************************************
** Meta object code from reading C++ file 'move_joint.h'
**
** Created: Thu Jan 12 23:45:13 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "move_joint.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'move_joint.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MoveJoint[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x08,
      33,   10,   10,   10, 0x08,
      55,   10,   10,   10, 0x08,
      77,   10,   10,   10, 0x08,
      99,   10,   10,   10, 0x08,
     121,   10,   10,   10, 0x08,
     143,   10,   10,   10, 0x08,
     165,   10,   10,   10, 0x08,
     185,   10,   10,   10, 0x08,
     203,   10,   10,   10, 0x08,
     223,   10,   10,   10, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MoveJoint[] = {
    "MoveJoint\0\0on_rdJoint7_clicked()\0"
    "on_rdJoint6_clicked()\0on_rdJoint5_clicked()\0"
    "on_rdJoint4_clicked()\0on_rdJoint3_clicked()\0"
    "on_rdJoint2_clicked()\0on_rdJoint1_clicked()\0"
    "on_btDown_clicked()\0on_btUp_clicked()\0"
    "on_btStop_clicked()\0on_btInit_clicked()\0"
};

const QMetaObject MoveJoint::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MoveJoint,
      qt_meta_data_MoveJoint, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MoveJoint::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MoveJoint::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MoveJoint::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MoveJoint))
        return static_cast<void*>(const_cast< MoveJoint*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MoveJoint::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_rdJoint7_clicked(); break;
        case 1: on_rdJoint6_clicked(); break;
        case 2: on_rdJoint5_clicked(); break;
        case 3: on_rdJoint4_clicked(); break;
        case 4: on_rdJoint3_clicked(); break;
        case 5: on_rdJoint2_clicked(); break;
        case 6: on_rdJoint1_clicked(); break;
        case 7: on_btDown_clicked(); break;
        case 8: on_btUp_clicked(); break;
        case 9: on_btStop_clicked(); break;
        case 10: on_btInit_clicked(); break;
        default: ;
        }
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
