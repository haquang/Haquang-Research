#ifndef MOVE_JOINT_H
#define MOVE_JOINT_H

#include <QMainWindow>
#include <sstream>
#include <string>
#include "qnode.h"
#include <QMessageBox>


namespace Ui {
    class MoveJoint;
}

class MoveJoint : public QMainWindow {
    Q_OBJECT
public:
    explicit MoveJoint(int argc,char ** argv,QWidget *parent = 0);
    ~MoveJoint();

protected:
    void changeEvent(QEvent *e);
    void DisAbleAllRadio();

private:
    Ui::MoveJoint *ui;
    Qnode qnode;
    int JointID;

private slots:
    void on_rdJoint7_clicked();
    void on_rdJoint6_clicked();
    void on_rdJoint5_clicked();
    void on_rdJoint4_clicked();
    void on_rdJoint3_clicked();
    void on_rdJoint2_clicked();
    void on_rdJoint1_clicked();
    void on_btDown_clicked();
    void on_btUp_clicked();
    void on_btStop_clicked();
    void on_btInit_clicked();
};

#endif // MOVE_JOINT_H
