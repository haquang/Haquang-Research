#ifndef QNODE_H
#define QNODE_H

#define signalslib signals
#define signals signals

#include <iostream>
#include <vector>

#include <ros/ros.h>
#include <cob_srvs/Trigger.h>
#include <pr2_controllers_msgs/JointTrajectoryAction.h>
#include <trajectory_msgs/JointTrajectory.h>
#include <actionlib/client/simple_action_client.h>

#include <boost/thread.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <QThread>

typedef enum  {Init, Stop, Recover} ActionMode;
typedef enum  {Position, Velocity} OperationMode;

typedef actionlib::SimpleActionClient< pr2_controllers_msgs::JointTrajectoryAction > TrajClient;

class Qnode:public QThread
{
public:
    static const int NJoint  =  7;  //7 DOF
    double jointVar[NJoint];
    std::string joint_name[NJoint];

    static const double jointMin = -3.14;
    static const double jointMax =  3.14;
    Qnode(int argc, char** argv);

    ~Qnode();
    void init();
    void run();

    bool initJoint();
    bool stopJoint();
    bool recoverJoint();
    bool changeJointOperationMode(const OperationMode &mode);
    double satuation(const double &angle);


    void sendCommand(const int JointID);

private:
    int     init_argc;
    char**  init_argv;
    ros::NodeHandle nh;
    ros::Publisher  command_pub;
    ros::ServiceClient init_client;
    ros::ServiceClient stop_client;
    ros::ServiceClient recover_client;
    ros::ServiceClient operation_client;
    boost::thread t;
    TrajClient *traj_client_;
};

#endif // QNODE_H
