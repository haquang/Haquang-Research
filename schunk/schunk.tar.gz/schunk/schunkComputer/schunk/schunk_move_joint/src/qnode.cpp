#include "qnode.h"

Qnode::Qnode(int argc, char** argv)
{
    init_argc = argc;
    init_argv = argv;

    jointVar[0] = 0.0;
    jointVar[1] = 0.0;
    jointVar[2] = 0.0;
    jointVar[3] = 0.0;
    jointVar[4] = 0.0;
    jointVar[5] = 0.0;
    jointVar[6] = 0.0;

    joint_name[0]  = "arm_1_joint";
    joint_name[1]  = "arm_2_joint";
    joint_name[2]  = "arm_3_joint";
    joint_name[3]  = "arm_4_joint";
    joint_name[4]  = "arm_5_joint";
    joint_name[5]  = "arm_6_joint";
    joint_name[6]  = "arm_7_joint";

}
void Qnode::init()
{
    ros::init(init_argc, init_argv,"move_joint");
    ros::start();          // our node handles go out of scope, so we want to control shutdown explicitly.

    start();

    command_pub  = nh.advertise<trajectory_msgs::JointTrajectory>("/schunk_controller/command",1);
    init_client  = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/init");
    stop_client  = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/stop");
    recover_client = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/recover");
    operation_client = nh.serviceClient<cob_srvs::Trigger>("/schunk_controller/set_operation_mode");

    //t = boost::thread(boost::bind(&Qnode::sendCommand, this));
    traj_client_ = new TrajClient("/schunk_controller/joint_trajectory_action", true);

    // wait for action server to come up
      while(!traj_client_->waitForServer(ros::Duration(5.0)))
        {
            ROS_INFO("Waiting for the joint_trajectory_action server");
        }
}

void Qnode::run()
{
    //ros::Rate loop_rate(1);
    ros::spin();
}
Qnode::~Qnode()
{
    ros::shutdown();
    std::cout  << "Waiting for ros thread to finish..." << std::endl;
    t.join();
    wait();
    delete traj_client_;
}

bool Qnode::initJoint()
{
    cob_srvs::Trigger  srv;   
    if(!init_client.call(srv))
    {
        ROS_INFO("%s", srv.response.error_message);
        return false;
    }
    else
    {
        ROS_INFO("Init Joint Success");
        return true;
    }
}
bool Qnode::stopJoint()
{
    cob_srvs::Trigger  srv;
    if(!stop_client.call(srv))
    {
        ROS_INFO("%s", srv.response.error_message);
        return false;
    }
    else
    {
        ROS_INFO("Stop Joint Success");
        return true;
    }

}


bool Qnode::recoverJoint()
{
    cob_srvs::Trigger  srv;
    if(!recover_client.call(srv))
    {
        ROS_INFO("%s", srv.response.error_message);
        return false;
    }
    else
    {
        ROS_INFO("Recover Joint Success");
        return true;
    }
}

double Qnode::satuation(const double &angle)
{
    double temp = angle;
    if(angle  > jointMax)
    {
        temp = jointMax;
    }
    if(angle < jointMin)
    {
        temp = jointMin;
    }
    return temp;
}

void Qnode::sendCommand(const int JointID)  // 0 ,1, 2, 3, 4, 5, 6
{
    if(JointID > 6 )
    {
        return;
    }
    else if(JointID < 0)
    {
        return;
    }
    pr2_controllers_msgs::JointTrajectoryGoal goal;
    goal.trajectory.header.stamp = ros::Time::now();
    goal.trajectory.header.frame_id  = "/base_link";
    goal.trajectory.joint_names.push_back(joint_name[0]);
    goal.trajectory.joint_names.push_back(joint_name[1]);
    goal.trajectory.joint_names.push_back(joint_name[2]);
    goal.trajectory.joint_names.push_back(joint_name[3]);
    goal.trajectory.joint_names.push_back(joint_name[4]);
    goal.trajectory.joint_names.push_back(joint_name[5]);
    goal.trajectory.joint_names.push_back(joint_name[6]);

    goal.trajectory.points.resize(1);
    goal.trajectory.points[0].positions.resize(NJoint);

    for(int i = 0; i < NJoint; i++ )
    {
        if(i == JointID)
        {
            goal.trajectory.points[0].positions[i]  = jointVar[JointID];
        }
        else
        {
            goal.trajectory.points[0].positions[i]  = 0.0;
        }
    }

    goal.trajectory.points[0].velocities.resize(NJoint);

    for(int i = 0; i < NJoint; i++ )
    {
        goal.trajectory.points[0].velocities[0] = 0.0;
    }

    goal.trajectory.points[0].time_from_start = ros::Duration(0.0);
    traj_client_->sendGoal(goal);

    while(traj_client_->getState().isDone() && ros::ok())
    {
        usleep(50000);
    }

}
