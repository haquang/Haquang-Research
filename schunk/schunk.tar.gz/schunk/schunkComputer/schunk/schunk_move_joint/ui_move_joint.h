/********************************************************************************
** Form generated from reading UI file 'move_joint.ui'
**
** Created: Thu Jan 12 23:45:13 2012
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOVE_JOINT_H
#define UI_MOVE_JOINT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MoveJoint
{
public:
    QWidget *centralwidget;
    QPushButton *btInit;
    QPushButton *btStop;
    QPushButton *btUp;
    QPushButton *btDown;
    QRadioButton *rdJoint1;
    QRadioButton *rdJoint2;
    QRadioButton *rdJoint3;
    QRadioButton *rdJoint4;
    QRadioButton *rdJoint5;
    QRadioButton *rdJoint6;
    QRadioButton *rdJoint7;
    QLineEdit *txtJoint1;
    QLineEdit *txtJoint2;
    QLineEdit *txtJoint3;
    QLineEdit *txtJoint4;
    QLineEdit *txtJoint5;
    QLineEdit *txtJoint6;
    QLineEdit *txtJoint7;
    QLabel *lbSchunk;
    QMenuBar *menubar;
    QStatusBar *statusbar;
    QButtonGroup *m_radio_group;

    void setupUi(QMainWindow *MoveJoint)
    {
        if (MoveJoint->objectName().isEmpty())
            MoveJoint->setObjectName(QString::fromUtf8("MoveJoint"));
        MoveJoint->resize(605, 361);
        centralwidget = new QWidget(MoveJoint);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        btInit = new QPushButton(centralwidget);
        btInit->setObjectName(QString::fromUtf8("btInit"));
        btInit->setGeometry(QRect(30, 70, 93, 27));
        btStop = new QPushButton(centralwidget);
        btStop->setObjectName(QString::fromUtf8("btStop"));
        btStop->setGeometry(QRect(30, 180, 93, 27));
        btUp = new QPushButton(centralwidget);
        btUp->setObjectName(QString::fromUtf8("btUp"));
        btUp->setGeometry(QRect(190, 70, 93, 27));
        btDown = new QPushButton(centralwidget);
        btDown->setObjectName(QString::fromUtf8("btDown"));
        btDown->setGeometry(QRect(190, 180, 93, 27));
        rdJoint1 = new QRadioButton(centralwidget);
        m_radio_group = new QButtonGroup(MoveJoint);
        m_radio_group->setObjectName(QString::fromUtf8("m_radio_group"));
        m_radio_group->addButton(rdJoint1);
        rdJoint1->setObjectName(QString::fromUtf8("rdJoint1"));
        rdJoint1->setGeometry(QRect(320, 20, 109, 22));
        rdJoint2 = new QRadioButton(centralwidget);
        m_radio_group->addButton(rdJoint2);
        rdJoint2->setObjectName(QString::fromUtf8("rdJoint2"));
        rdJoint2->setGeometry(QRect(320, 60, 109, 22));
        rdJoint3 = new QRadioButton(centralwidget);
        m_radio_group->addButton(rdJoint3);
        rdJoint3->setObjectName(QString::fromUtf8("rdJoint3"));
        rdJoint3->setGeometry(QRect(320, 100, 109, 22));
        rdJoint4 = new QRadioButton(centralwidget);
        m_radio_group->addButton(rdJoint4);
        rdJoint4->setObjectName(QString::fromUtf8("rdJoint4"));
        rdJoint4->setGeometry(QRect(320, 140, 109, 22));
        rdJoint5 = new QRadioButton(centralwidget);
        m_radio_group->addButton(rdJoint5);
        rdJoint5->setObjectName(QString::fromUtf8("rdJoint5"));
        rdJoint5->setGeometry(QRect(320, 180, 109, 22));
        rdJoint6 = new QRadioButton(centralwidget);
        m_radio_group->addButton(rdJoint6);
        rdJoint6->setObjectName(QString::fromUtf8("rdJoint6"));
        rdJoint6->setGeometry(QRect(320, 220, 109, 22));
        rdJoint7 = new QRadioButton(centralwidget);
        m_radio_group->addButton(rdJoint7);
        rdJoint7->setObjectName(QString::fromUtf8("rdJoint7"));
        rdJoint7->setGeometry(QRect(320, 260, 109, 22));
        txtJoint1 = new QLineEdit(centralwidget);
        txtJoint1->setObjectName(QString::fromUtf8("txtJoint1"));
        txtJoint1->setGeometry(QRect(450, 10, 113, 27));
        txtJoint2 = new QLineEdit(centralwidget);
        txtJoint2->setObjectName(QString::fromUtf8("txtJoint2"));
        txtJoint2->setGeometry(QRect(450, 50, 113, 27));
        txtJoint3 = new QLineEdit(centralwidget);
        txtJoint3->setObjectName(QString::fromUtf8("txtJoint3"));
        txtJoint3->setGeometry(QRect(450, 90, 113, 27));
        txtJoint4 = new QLineEdit(centralwidget);
        txtJoint4->setObjectName(QString::fromUtf8("txtJoint4"));
        txtJoint4->setGeometry(QRect(450, 130, 113, 27));
        txtJoint5 = new QLineEdit(centralwidget);
        txtJoint5->setObjectName(QString::fromUtf8("txtJoint5"));
        txtJoint5->setGeometry(QRect(450, 170, 113, 27));
        txtJoint6 = new QLineEdit(centralwidget);
        txtJoint6->setObjectName(QString::fromUtf8("txtJoint6"));
        txtJoint6->setGeometry(QRect(450, 210, 113, 27));
        txtJoint7 = new QLineEdit(centralwidget);
        txtJoint7->setObjectName(QString::fromUtf8("txtJoint7"));
        txtJoint7->setGeometry(QRect(450, 250, 113, 27));
        lbSchunk = new QLabel(centralwidget);
        lbSchunk->setObjectName(QString::fromUtf8("lbSchunk"));
        lbSchunk->setGeometry(QRect(81, 249, 131, 31));
        MoveJoint->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MoveJoint);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 605, 23));
        MoveJoint->setMenuBar(menubar);
        statusbar = new QStatusBar(MoveJoint);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MoveJoint->setStatusBar(statusbar);

        retranslateUi(MoveJoint);

        QMetaObject::connectSlotsByName(MoveJoint);
    } // setupUi

    void retranslateUi(QMainWindow *MoveJoint)
    {
        MoveJoint->setWindowTitle(QApplication::translate("MoveJoint", "MainWindow", 0, QApplication::UnicodeUTF8));
        btInit->setText(QApplication::translate("MoveJoint", "Initialize", 0, QApplication::UnicodeUTF8));
        btStop->setText(QApplication::translate("MoveJoint", "Stop", 0, QApplication::UnicodeUTF8));
        btUp->setText(QApplication::translate("MoveJoint", "Up", 0, QApplication::UnicodeUTF8));
        btDown->setText(QApplication::translate("MoveJoint", "Down", 0, QApplication::UnicodeUTF8));
        rdJoint1->setText(QApplication::translate("MoveJoint", "arm_1_joint", 0, QApplication::UnicodeUTF8));
        rdJoint2->setText(QApplication::translate("MoveJoint", "arm_2_joint", 0, QApplication::UnicodeUTF8));
        rdJoint3->setText(QApplication::translate("MoveJoint", "arm_3_joint", 0, QApplication::UnicodeUTF8));
        rdJoint4->setText(QApplication::translate("MoveJoint", "arm_4_joint", 0, QApplication::UnicodeUTF8));
        rdJoint5->setText(QApplication::translate("MoveJoint", "arm_5_joint", 0, QApplication::UnicodeUTF8));
        rdJoint6->setText(QApplication::translate("MoveJoint", "arm_6_joint", 0, QApplication::UnicodeUTF8));
        rdJoint7->setText(QApplication::translate("MoveJoint", "arm_7_joint", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MoveJoint: public Ui_MoveJoint {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOVE_JOINT_H
