#include <ros/ros.h>
#include <tf/transform_listener.h>


int main(int argc, char** argv){
  ros::init(argc, argv, "my_tf_listener");

  ros::NodeHandle node;

  tf::TransformListener listener;

    tf::StampedTransform transform;
  ros::Rate rate(10.0);
  while (node.ok()){
    try{
      listener.lookupTransform("/base_link", "/arm_7_link",  
                               ros::Time(0), transform);
    }
    catch (tf::TransformException ex){
      ROS_ERROR("%s",ex.what());
    }
	
        ROS_INFO("Tranform: X %f Y %f Z %f",transform.getOrigin().x(),transform.getOrigin().y(),transform.getOrigin().z());
    rate.sleep();
  }
  return 0;
};


