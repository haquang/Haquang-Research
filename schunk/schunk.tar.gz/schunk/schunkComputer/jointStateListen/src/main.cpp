#include "ros/ros.h"
#include <pr2_controllers_msgs/JointTrajectoryAction.h>
#include <trajectory_msgs/JointTrajectory.h>


void chatterCallback(const pr2_controllers_msgs::JointTrajectoryControllerState controllermsg)
{
  ROS_INFO("I heard: [%s]", msg->data.c_str());
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "listener");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("joint_states", 1000, chatterCallback);

  ros::spin();

  return 0;
}


