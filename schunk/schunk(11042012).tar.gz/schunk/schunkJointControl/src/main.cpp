#include <ros/ros.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <actionlib/client/simple_action_client.h>
#include <trajectory_msgs/JointTrajectory.h>
#include <sensor_msgs/JointState.h>

typedef actionlib::SimpleActionClient <control_msgs::FollowJointTrajectoryAction > TrajClient;
#define N_DOF 7
// Variable
TrajClient * traj_client_; //Trajectory
control_msgs::FollowJointTrajectoryGoal goal;
int i;

actionlib::SimpleClientGoalState getState()
{
	return traj_client_->getState();
}

void startTrajectory()
{
	// When to start the trajectory: 1s from now
	goal.trajectory.header.stamp = ros::Time::now() + ros::Duration(1.0);
	traj_client_->sendGoal(goal);
}

void jointCommandCallback(const sensor_msgs::JointState msg)
{
	traj_client_ = new TrajClient("/arm_controller/follow_joint_trajectory", true);
	while(!traj_client_->waitForServer(ros::Duration(1.0))){
		ROS_INFO("Waiting for the joint_trajectory_action server");
	}
	// Position
	goal.trajectory.points[0].positions.resize(N_DOF);
	for (int j=0;j<N_DOF;j++)
		goal.trajectory.points[0].positions[j] = msg.position[j];

	//Velocity
	goal.trajectory.points[0].velocities.resize(N_DOF);
	for (int j=0;j<N_DOF;j++)
		goal.trajectory.points[0].velocities[j] = msg.velocity[j];

	goal.trajectory.points[0].time_from_start = ros::Duration(10.0);

	//start Trajectory
	startTrajectory();
	while(!getState().isDone())
	{

	}
	delete traj_client_;
}


void initialize()
{
	traj_client_ = new TrajClient("/arm_controller/follow_joint_trajectory", true);
	while(!traj_client_->waitForServer(ros::Duration(5.0))){
		ROS_INFO("Waiting for the joint_trajectory_action server");
	}

	//init goal
	goal.trajectory.joint_names.push_back("arm_1_joint");
	goal.trajectory.joint_names.push_back("arm_2_joint");
	goal.trajectory.joint_names.push_back("arm_3_joint");
	goal.trajectory.joint_names.push_back("arm_4_joint");
	goal.trajectory.joint_names.push_back("arm_5_joint");
	goal.trajectory.joint_names.push_back("arm_6_joint");
	goal.trajectory.joint_names.push_back("arm_7_joint");

	goal.trajectory.points.resize(1);
	goal.trajectory.points[0].positions.resize(N_DOF);

	// set to the original position
	goal.trajectory.points[0].positions.resize(N_DOF);
	for (int j=0;j<N_DOF;j++)
		goal.trajectory.points[0].positions[j] = 0.0;

	goal.trajectory.points[0].positions[0] = 0.0;
	goal.trajectory.points[0].positions[1] = 0.0;
	goal.trajectory.points[0].positions[2] = 0.0;
	goal.trajectory.points[0].positions[3] = 0.0;
	goal.trajectory.points[0].positions[4] = 0.0;
	goal.trajectory.points[0].positions[5] = 0.0;
	goal.trajectory.points[0].positions[6] = 0;
	goal.trajectory.points[0].velocities.resize(7);


	for (size_t j = 0; j < 7; ++j)
	{
		goal.trajectory.points[0].velocities[j] = 0.0;
	}

	// To be reached 2 seconds after starting along the trajectory
	goal.trajectory.points[0].time_from_start = ros::Duration(10.0);

	//start Trajectory
	startTrajectory();

	while(!getState().isDone())
	{

	}
	delete traj_client_;
}
int main(int argc, char** argv)
{
	//Init the ROS node
	ros::init(argc, argv, "schunkJointController");
	ros::NodeHandle n;
	// Initialize
	initialize();

	// subriber
	ros::Subscriber sub = n.subscribe("/joint_states_command", 1, jointCommandCallback);
	// Wait for trajectory completion
	while (n.ok())
	{
		ros::spinOnce();
	}

}
