// Haptic Device headers
#include <HD/hd.h>
#include <HDU/hduError.h>
#include <HDU/hduVector.h>
#include <HDU/hduMatrix.h>
#include <HDU/hduQuaternion.h>
#include <iostream>

#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <kdl/frames.hpp>
#include <tf/transform_broadcaster.h>


using namespace std;
//Others
#include "conio.h"

using namespace std;
//Function definition
int OmniOpen(void);
int OmniRun(void);
void OmniClose(void);
void OmniCalibrate(void);
void mainLoop();
HDCallbackCode HDCALLBACK omni_callback(void *pUserData);
void sendMasterMarkerPos(const float &x, const float &y, const float &z);

// Global Variable
HDErrorInfo error;
HHD hHD;
HDCallbackCode hOmniCallback;

hduVector3Dd Position;
hduMatrix   Orientation;
hduQuaternion qOrientation;
hduQuaternion deltaOrientation;
hduVector3Dd deltaPosition;

hduQuaternion prvOrientation;
hduVector3Dd prvPosition;

hduVector3Dd initPosition;
hduQuaternion initOrientation;
hduVector3Dd force;
bool start = true;
ros::Publisher pose_pub;

KDL::Rotation kdlOrientation;
geometry_msgs::Pose omniPose;
ros::Publisher endEffPos_pub;

int buttons[2];


void Saturation(double *force){
	if (force[0]<-5) force[0]=-5;
	if (force[1]<-5) force[1]=-5;
	if (force[2]<-5) force[2]=-5;
	if (force[0]>5) force[0]=5;
	if (force[1]>5) force[1]=5;
	if (force[2]>5) force[2]=5;
}


int main(int argc,char* argv[]) {

	//Init Omini
	OmniOpen();
	//Init ROS
	ros::init(argc, argv , "Omni");
	ros::NodeHandle nh;
	pose_pub = nh.advertise<geometry_msgs::Pose>("/OmniPose",1);
	endEffPos_pub = nh.advertise<geometry_msgs::Pose>("/EndEffectorCommand", 1);

	//Asign callback
	hOmniCallback = hdScheduleAsynchronous(omni_callback, 0, HD_MAX_SCHEDULER_PRIORITY);
	hdSetSchedulerRate(1000);

	//Start Omini Scheduler
	OmniRun();

	while (nh.ok())
	{
		ros::spinOnce();
	}
	OmniClose();
	return 0;
}



int OmniOpen()
{
	// Initialize the default haptic device.
	HHD hHD = hdInitDevice(HD_DEFAULT_DEVICE);
	if (HD_DEVICE_ERROR(error = hdGetError()))
	{
		ROS_ERROR("Failed to open!");
		return -1;
	}

	// Start the servo scheduler and enable forces.
	hdEnable(HD_FORCE_OUTPUT);
	//printf("Position x = %lf, y = %lf, z = %lf", Position[0], Position[1], Position[2] );
	OmniCalibrate();
	return 0; //if successful
}
int OmniRun()
{
	// Start Scheduler
	hdStartScheduler();
	if (HD_DEVICE_ERROR(error = hdGetError()))
	{
		ROS_ERROR("Failed to run!");
		return -1;
	}
	return 0;
}

void OmniClose()
{
	hdStopScheduler();
	hdUnschedule(hOmniCallback);
	hdDisableDevice(hHD);
}
void mainLoop()
{
	char key;
	ros::spin();
	do
	{
		key = getchar();
	}while(key != 27);
}
void OmniCalibrate(void)
{
	int calibrationStyle;
	int supportedCalibrationStyles;
	HDErrorInfo error;

	hdGetIntegerv(HD_CALIBRATION_STYLE, &supportedCalibrationStyles);
	if (supportedCalibrationStyles & HD_CALIBRATION_ENCODER_RESET)
	{
		calibrationStyle = HD_CALIBRATION_ENCODER_RESET;
		printf("HD_CALIBRATION_ENCODER_RESE..\n\n");
	}
	if (supportedCalibrationStyles & HD_CALIBRATION_INKWELL)
	{
		calibrationStyle = HD_CALIBRATION_INKWELL;
		printf("HD_CALIBRATION_INKWELL..\n\n");
	}
	if (supportedCalibrationStyles & HD_CALIBRATION_AUTO)
	{
		calibrationStyle = HD_CALIBRATION_AUTO;
		printf("HD_CALIBRATION_AUTO..\n\n");
	}

	do
	{
		hdUpdateCalibration(calibrationStyle);
		printf("Calibrating.. (put stylus in well)\n");
		if (HD_DEVICE_ERROR(error = hdGetError()))
		{
			hduPrintError(stderr, &error, "Reset encoders reset failed.");
			break;
		}
	}   while (hdCheckCalibration() != HD_CALIBRATION_OK);

	printf("\n\nCalibration complete.\n");
}
HDCallbackCode HDCALLBACK omni_callback(void *pUserData)
{
	hdBeginFrame(hdGetCurrentDevice());
	hdGetDoublev(HD_CURRENT_POSITION, Position);
	hdGetDoublev(HD_CURRENT_TRANSFORM,Orientation);
	hdGetIntegerv(HD_CURRENT_BUTTONS, buttons);
	if (start)
	{
		initPosition = Position;
		start = false;
		hdEndFrame(hdGetCurrentDevice());
		return HD_CALLBACK_CONTINUE;
	}

	Position = Position - initPosition;
	Orientation.getRotation(qOrientation);

	//printf("Position x = %lf, y = %lf, z = %lf\n", Position[0], Position[1], Position[2] );

	if (buttons[0]==1)
	{
		omniPose.position.x = 0;
		omniPose.position.y = 0;
		omniPose.position.z = 1.6672;

	}
	else
	{
		omniPose.position.x = -Position[0]/1000;
		omniPose.position.y = Position[2]/1000;
		omniPose.position.z = 1.2+Position[1]/1000;

	}
	//x = z, y = x, z = y
	//omniPose.position.z = Position[2]/500;


	omniPose.orientation.w = qOrientation.s(); //Angle
	omniPose.orientation.x = qOrientation.v()[0]; //Axis
	omniPose.orientation.y = qOrientation.v()[2]; //Axis
	omniPose.orientation.z = qOrientation.v()[1]; //Axis


	endEffPos_pub.publish(omniPose);


	tf::Transform transform;
	transform.setOrigin( tf::Vector3(omniPose.position.x, omniPose.position.y,omniPose.position.z));

	//publish Tranform
	tf::Quaternion q;
	q.setX(omniPose.orientation.x);
	q.setY(omniPose.orientation.y);
	q.setZ(omniPose.orientation.z);
	q.setW(omniPose.orientation.w);
	transform.setRotation(q);


	static tf::TransformBroadcaster br;
	br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "/base_link","OmniPose"));



	ROS_INFO("Position: %5f   %5f   %5f",omniPose.position.x,omniPose.position.y,omniPose.position.z);
	ROS_INFO("Orientation: %5f   %5f   %5f    %5f",omniPose.orientation.x,omniPose.orientation.y,omniPose.orientation.z,omniPose.orientation.w);
	pose_pub.publish(omniPose);


	//ROS_INFO("Force: %5f   %5f   %5f",force[0],force[1],force[2]);
	hdEndFrame(hdGetCurrentDevice());

	HDErrorInfo error;
	if (HD_DEVICE_ERROR(error = hdGetError()))
	{
		hduPrintError(stderr, &error, "Error during main scheduler callback\n");
		if (hduIsSchedulerError(&error))
			return HD_CALLBACK_DONE;
	}

	prvOrientation = qOrientation;
	prvPosition = Position;

	return HD_CALLBACK_CONTINUE;

}
