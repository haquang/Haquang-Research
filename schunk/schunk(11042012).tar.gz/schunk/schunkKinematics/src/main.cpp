#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Pose.h>
#include <kinematics_msgs/GetKinematicSolverInfo.h>
#include <kinematics_msgs/GetPositionFK.h>
#include <kinematics_msgs/GetPositionIK.h>
#include <kinematics_msgs/GetKinematicSolverInfo.h>
#include <kinematics_msgs/GetPositionFK.h>
#include <kinematics_msgs/GetPositionIK.h>
#include <kdl/frames.hpp>
#include <visualization_msgs/Marker.h>
#include <tf/transform_broadcaster.h>


const unsigned int N_DOF = 7;
int j;
// define the service messages
kinematics_msgs::GetKinematicSolverInfo::Request request;
kinematics_msgs::GetKinematicSolverInfo::Response response;
// define the service messages
kinematics_msgs::GetPositionFK::Request  fk_request;
kinematics_msgs::GetPositionFK::Response fk_response;
ros::ServiceClient query_client;
ros::ServiceClient fk_client;

// define the service messages
kinematics_msgs::GetPositionIK::Request  gpik_req;
kinematics_msgs::GetPositionIK::Response gpik_res;
ros::ServiceClient ik_client;


sensor_msgs::JointState robotJoints;
sensor_msgs::JointState robotJointsDesign;
visualization_msgs::Marker robotPoseMarker;
//geometry_msgs::Pose robotPose;
geometry_msgs::Pose robotPoseDesign;


/*
 * Forward Kinematics
 */
void getFK_Info()
{
	if(query_client.call(request,response))
	{
		for(unsigned int i=0;i< response.kinematic_solver_info.joint_names.size(); i++)
		{
			ROS_INFO("Joint: %d %s", i,response.kinematic_solver_info.joint_names[i].c_str());
		}
	}
	else
	{
		ROS_ERROR("Could not call query service");
		ros::shutdown();
		exit(1);
	}
}

void getFK()
{
	fk_request.header.frame_id = "base_link";
	fk_request.fk_link_names.resize(1);
	fk_request.fk_link_names[0] = "arm_7_link";

	fk_request.robot_state.joint_state.position.resize(response.kinematic_solver_info.joint_names.size());
	fk_request.robot_state.joint_state.name =response.kinematic_solver_info.joint_names;

	for(unsigned int i=0;i< response.kinematic_solver_info.joint_names.size(); i++)
	{
		fk_request.robot_state.joint_state.position[i] = robotJoints.position[i];
	}
	if(fk_client.call(fk_request, fk_response))
	{
		if(fk_response.error_code.val == fk_response.error_code.SUCCESS)
		{
			robotPoseDesign.position = fk_response.pose_stamped[0].pose.position;
			robotPoseDesign.orientation = fk_response.pose_stamped[0].pose.orientation;
		}
		else
		{
			ROS_ERROR("Forward kinematics failed");
		}
	}
	else
	{
		ROS_ERROR("Forward kinematics service call failed");
	}

}

/*
 * Inverse Kinematics
 */

void getIK_Info()
{
	if(query_client.call(request,response))
	{
		for(unsigned int i=0; i< response.kinematic_solver_info.joint_names.size(); i++)
		{
			ROS_DEBUG("Joint: %d %s",i,response.kinematic_solver_info.joint_names[i].c_str());
		}
	}
	else
	{
		ROS_ERROR("Could not call query service");
		ros::shutdown();
		exit(1);
	}
}

int getIK()
{
	gpik_req.timeout = ros::Duration(5.0);
	gpik_req.ik_request.ik_link_name = "arm_7_link";

	gpik_req.ik_request.pose_stamped.header.frame_id = "base_link";

	gpik_req.ik_request.pose_stamped.pose = robotPoseDesign;

	gpik_req.ik_request.ik_seed_state.joint_state.position.resize(response.kinematic_solver_info.joint_names.size());
	gpik_req.ik_request.ik_seed_state.joint_state.name = response.kinematic_solver_info.joint_names;


	for(unsigned int i=0; i< response.kinematic_solver_info.joint_names.size(); i++)
	{
		gpik_req.ik_request.ik_seed_state.joint_state.position[i] = (response.kinematic_solver_info.limits[i].min_position + response.kinematic_solver_info.limits[i].max_position)/2.0;
	}
	if(ik_client.call(gpik_req, gpik_res))
	{
		if(gpik_res.error_code.val == gpik_res.error_code.SUCCESS)
		{
			robotJointsDesign = gpik_res.solution.joint_state;
			robotJointsDesign.set_velocity_size(N_DOF);
		}
		else
		{
			ROS_ERROR("Inverse kinematics failed");
			return -1;
		}

	}
	else{
		ROS_ERROR("Inverse kinematics service call failed");
		return -1;
	}
	return 0;


}

/*
 * Callback function
 */

void jointStateCB(const sensor_msgs::JointState msg)
{
	robotJoints.position = msg.position;
}
void EndEffectorCommand(const geometry_msgs::Pose msg)
{
	robotPoseDesign = msg;
}
/*
 * main program
 */
int main(int argc, char **argv){
	ros::init (argc, argv, "schunkKinematics");
	ros::NodeHandle n;

	// Subriber for joint states
	ros::Subscriber sub = n.subscribe("joint_states", 100, jointStateCB);
	ros::Subscriber subEndEffector = n.subscribe("/EndEffectorCommand", 100,EndEffectorCommand);

	//publisher
	ros::Publisher pose_pub = n.advertise<geometry_msgs::Pose>("EndEffectorPose", 1);
	ros::Publisher markerDesigPose_pub = n.advertise<visualization_msgs::Marker>("Marker", 1);
	ros::Publisher joint_pub = n.advertise<sensor_msgs::JointState>("/joint_states_command",1);
	// Set our initial shape type to be a sphere
	uint32_t shape = visualization_msgs::Marker::SPHERE;

	visualization_msgs::Marker markerPoseDesign;

	robotJoints.position.resize(N_DOF);
	robotJoints.velocity.resize(N_DOF);

	ros::service::waitForService("/arm_m_chain_kinematics/get_fk_solver_info");
	ros::service::waitForService("/arm_m_chain_kinematics/get_fk");


	query_client =n.serviceClient<kinematics_msgs::GetKinematicSolverInfo>("/arm_m_chain_kinematics/get_fk_solver_info");
	fk_client = n.serviceClient	<kinematics_msgs::GetPositionFK>("/arm_m_chain_kinematics/get_fk");
	getFK_Info();

	ros::service::waitForService("/arm_m_chain_kinematics/get_ik_solver_info");
	ros::service::waitForService("/arm_m_chain_kinematics/get_ik");

	query_client = n.serviceClient<kinematics_msgs::GetKinematicSolverInfo>("/arm_m_chain_kinematics/get_ik_solver_info");
	ik_client = n.serviceClient<kinematics_msgs::GetPositionIK>("/arm_m_chain_kinematics/get_ik");

	getIK_Info();

	static tf::TransformBroadcaster br;

	robotPoseDesign.position.x = 0.0;
	robotPoseDesign.position.y = 0.0;
	robotPoseDesign.position.z = 1.6672;

	robotPoseDesign.orientation.x = 0;
	robotPoseDesign.orientation.y = 1;
	robotPoseDesign.orientation.z = 0;
	robotPoseDesign.orientation.w = 0;

	while (n.ok())
	{
		//	getFK();
		ROS_INFO("Position: %5f   %5f   %5f",robotPoseDesign.position.x,robotPoseDesign.position.y,robotPoseDesign.position.z);
		ROS_INFO("Orientation: %5f   %5f   %5f    %5f",robotPoseDesign.orientation.x,robotPoseDesign.orientation.y,robotPoseDesign.orientation.z,robotPoseDesign.orientation.w);
		if (getIK()==0)
		{
			//			ROS_INFO("Actual Joints: %5f %5f %5f %5f %5f %5f %5f",robotJoints.position[0],robotJoints.position[1],robotJoints.position[2],
			//										robotJoints.position[3],robotJoints.position[4],robotJoints.position[5],robotJoints.position[6]);
			ROS_INFO("Desired Joints: %5f %5f %5f %5f %5f %5f %5f",robotJointsDesign.position[0],robotJointsDesign.position[1],robotJointsDesign.position[2],
					robotJointsDesign.position[3],robotJointsDesign.position[4],robotJointsDesign.position[5],robotJointsDesign.position[6]);
		}
		else
		{
			ROS_ERROR("Error inverse kinematics");
		}
		KDL::Rotation rot;
		tf::Transform transform;
		transform.setOrigin( tf::Vector3(robotPoseDesign.position.x, robotPoseDesign.position.y,robotPoseDesign.position.z));

		//publish Tranform
		tf::Quaternion q;
		q.setX(robotPoseDesign.orientation.x);
		q.setY(robotPoseDesign.orientation.y);
		q.setZ(robotPoseDesign.orientation.z);
		q.setW(robotPoseDesign.orientation.w);
		transform.setRotation(q);
		br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "/base_link","EndEffector"));

		//Publish Marker
		markerPoseDesign.header.frame_id = "/base_link";
		markerPoseDesign.header.stamp = ros::Time::now();
		markerPoseDesign.ns = "basic_shapes";
		markerPoseDesign.id = 0;
		markerPoseDesign.type = shape;

		markerPoseDesign.action = visualization_msgs::Marker::ADD;
		markerPoseDesign.pose.position.x = robotPoseDesign.position.x;
		markerPoseDesign.pose.position.y = robotPoseDesign.position.y;
		markerPoseDesign.pose.position.z = robotPoseDesign.position.z;
		markerPoseDesign.pose.orientation.x = robotPoseDesign.orientation.x;
		markerPoseDesign.pose.orientation.y = robotPoseDesign.orientation.y;
		markerPoseDesign.pose.orientation.z = robotPoseDesign.orientation.z;
		markerPoseDesign.pose.orientation.w = robotPoseDesign.orientation.w;

		// Set the scale of the marker -- 1x1x1 here means 1m on a side
		markerPoseDesign.scale.x = 0.05;
		markerPoseDesign.scale.y = 0.05;
		markerPoseDesign.scale.z = 0.05;

		markerPoseDesign.set_points_size(0.1);
		// Set the color -- be sure to set alpha to something non-zero!
		markerPoseDesign.color.r = 1.0f;
		markerPoseDesign.color.g = 0.0f;
		markerPoseDesign.color.b = 0.0f;
		markerPoseDesign.color.a = 1.0;

		markerPoseDesign.lifetime = ros::Duration();

		joint_pub.publish(robotJointsDesign);
		pose_pub.publish(robotPoseDesign);
		markerDesigPose_pub.publish(markerPoseDesign);

		ros::spinOnce();
	}
}

